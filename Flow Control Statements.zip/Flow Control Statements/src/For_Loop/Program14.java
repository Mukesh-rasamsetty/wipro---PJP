//Write a program to check if a given number is prime or not.

package For_Loop;

public class Program14 {

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		boolean flag = true;
		if (n == 0 || n == 1) {
			System.out.println(n + " is neither prime nor composite");
		} else {
			for (int i = 2; i < n; i++) {
				if (n % i == 0)
					flag = false;
			}
			if (flag)
				System.out.println(n + " is Prime number");
			else
				System.out.println(n + " is not a prime number");
		}
	}

}
