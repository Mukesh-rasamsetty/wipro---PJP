//Write a program to print numbers from 1 to 10 in a single row with one tab space.

package For_Loop;

public class Program10 {

	public static void main(String[] args) {
		for (int i = 1; i < 11; i++)
			System.out.print(i + "	");
	}

}
