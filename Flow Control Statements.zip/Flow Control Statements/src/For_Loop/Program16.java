//Write a program to print * in Floyds format (using for and while loop)

package For_Loop;

public class Program16 {

	public static void main(String[] args) {
		if (args.length == 0)
			System.out.println("Please enter an integer number");
		else {
			for (int i = 0; i < Integer.parseInt(args[0]); i++) {
				for (int j = 0; j <= i; j++) {
					System.out.print("* ");
				}
				System.out.println();
			}
		}
	}

}
