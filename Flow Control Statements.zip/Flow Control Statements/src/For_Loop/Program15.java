//Write a program to print the sum of all the digits of a given number.

package For_Loop;

import java.util.Scanner;

public class Program15 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number : ");
		int n = sc.nextInt();
		int sum = 0;
		for (; n > 0; n = n / 10)
			sum += (n % 10);
		System.out.println(sum);
		sc.close();
	}

}
