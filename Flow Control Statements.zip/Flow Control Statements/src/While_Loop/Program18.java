//Write a Java program to find if the given number is palindrome or not

package While_Loop;

public class Program18 {

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		int rev = 0;
		int temp = n;
		while (n > 0) {
			rev = rev * 10 + (n % 10);
			n /= 10;
		}
		if (rev == temp)
			System.out.println(temp + " is a palindrome");
		else
			System.out.println(temp + " is not a palindrome");
	}

}
