//Write a program to print first 5 values which are divisible by 2, 3, and 5.

package While_Loop;

public class Program19 {

	public static void main(String[] args) {
		int i = 0, n = 5;
		while (i != 5) {
			if (n % 2 == 0 && n % 3 == 0 && n % 5 == 0)

			{
				System.out.println(n);
				i++;
			}
			n++;
		}
	}

}
