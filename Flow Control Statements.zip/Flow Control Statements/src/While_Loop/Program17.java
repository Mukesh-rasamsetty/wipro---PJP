//Write a program to reverse a given number and print

package While_Loop;

public class Program17 {

	public static void main(String[] args) {
		int n =Integer.parseInt(args[0]);
		int rev = 0;
		while(n>0)
		{
			rev = rev*10 + (n  % 10);
			n /=10;
		}
		System.out.println(rev);
	}

}
