/*
 *  Initialize a character variable with an alphabhet in a program.
 *  If the character value is in lowercase, the output should be displayed in uppercase in the following format.
 */
package if_statement;

import java.util.Scanner;

public class Program07 {

	public static void main(String[] args) {
		Scanner sc  = new Scanner(System.in);
		char ch = sc.next().charAt(0);
		if(ch>= 'a' && ch<= 'z')
			System.out.println((char)(ch-32));
		else
			System.out.println((char)(ch+32));
		sc.close();
	}

}
