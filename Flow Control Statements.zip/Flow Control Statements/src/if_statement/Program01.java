//Write a program to check if a given integer number is Positive, Negative, or Zero. 

package if_statement;

import java.util.Scanner;

public class Program01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number : ");
		int n = sc.nextInt();
		if (n < 0)
			System.out.println(n + " is Negative Number");
		else if (n > 0)
			System.out.println(n + " is Positive Number");
		else
			System.out.println("Given number is Zero");
		sc.close();
	}

}
