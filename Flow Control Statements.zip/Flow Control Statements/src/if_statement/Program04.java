// Initialize two character variables in a program and display the characters in alphabetical order.

package if_statement;

import java.util.Scanner;

public class Program04 {

	public static void main(String[] args) {
		char ch1, ch2;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two Characters : ");
		ch1 = sc.next().charAt(0);
		ch2 = sc.next().charAt(0);
		if (ch1 > ch2)
			System.out.println(ch2 + " , " + ch1);
		else
			System.out.println(ch1 + " , " + ch2);
		sc.close();
	}

}
