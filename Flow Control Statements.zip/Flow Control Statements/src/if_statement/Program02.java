//Write a program to check if a given integer number is odd or even.

package if_statement;

import java.util.Scanner;

public class Program02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number : ");
		int n = sc.nextInt();
		if (n % 2 == 0)
			System.out.println(n + " is Even Number");
		else
			System.out.println(n + " is Odd Number");
		sc.close();
	}

}
