/*Initialize a character variable in a program and 
 *print 'Alphabhet' if the initialized value is an alphabhet, 
 *print 'Digit' if the initialized value is a number, and 
 *print 'Special Character', if the initialized value is anything else.
 */

package if_statement;

import java.util.Scanner;

public class Program05 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		char ch1 = sc.next().charAt(0);
		if ((ch1 >= 'a' && ch1 <= 'z') || (ch1 >= 'A' && ch1 <= 'Z'))
			System.out.println("Alphabet");
		else if ((ch1 >= '0' && ch1 <= '9'))
			System.out.println("Digit");
		else
			System.out.println("Special Character");
		sc.close();
	}

}
