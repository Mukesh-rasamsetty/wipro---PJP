
public class BankMain {

	public static void main(String[] args) {
		ICICIBank i=new ICICIBank();
		System.out.println(i.getFixedDepositInterestRate()+"\t"+i.getSavingsIntersetRate());
		KotMBank k=new KotMBank();
		System.out.println(k.getFixedDepositInterestRate()+"\t"+k.getSavingsIntersetRate());
		GeneralBank g1=new KotMBank();
		System.out.println(g1.getFixedDepositInterestRate()+"\t"+g1.getSavingsIntersetRate());
		GeneralBank g2=new ICICIBank();
		System.out.println(g2.getFixedDepositInterestRate()+"\t"+g2.getSavingsIntersetRate());
	}

}
