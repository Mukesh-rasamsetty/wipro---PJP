
public class FirstClass extends Compartment {

	@Override
	public String notice() {
		return "First Class";
	}

}
