
public class KotMBank extends GeneralBank {

	@Override
	public double getSavingsIntersetRate() {
		return 6;
	}

	@Override
	public double getFixedDepositInterestRate() {
		return 9;
	}

}
