
public class Ladies extends Compartment {

	@Override
	public String notice() {
		return "Only for Ladies";
	}

}
