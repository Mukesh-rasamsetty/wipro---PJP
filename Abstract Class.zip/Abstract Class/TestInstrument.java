import java.util.Random;

public class TestInstrument {

	public static void main(String[] args) {
		Instrument[] instruments = new Instrument[10];
		Random rand;
		for (int i = 0; i < 10; i++) {
			rand = new Random();
			switch (rand.nextInt(10) % 3 + 1) {
			case 1:
				instruments[i] = new Piano();
				break;
			case 2:
				instruments[i] = new Flute();
				break;
			case 3:
				instruments[i] = new Guitar();
				break;
			default:
				System.out.println("Overload");
			}
		}
		for (int i = 0; i < 10; i++) {
			if (instruments[i] instanceof Piano) {
				System.out.println("****************PIANO****************");
			} else if (instruments[i] instanceof Flute) {
				System.out.println("****************FLUTE****************");
			} else if (instruments[i] instanceof Guitar) {
				System.out.println("****************GUITAR****************");
			} else {
				System.out.println("Garbage................!");
			}
			instruments[i].play();
		}
	}

}
