
public abstract class GeneralBank {
	public abstract double getSavingsIntersetRate();

	public abstract double getFixedDepositInterestRate();
}
