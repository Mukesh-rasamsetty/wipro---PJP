
public class Luggage extends Compartment{

	@Override
	public String notice() {
		return "Luggage";
	}

}
