
public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		LibraryUser Kid = new KidUsers(30, "Kids");
		Kid.registerAccount();
		Kid.requestBook();
		Kid = new KidUsers(12, "Kids");
		Kid.registerAccount();
		Kid.requestBook();
		Kid = new KidUsers(11, "Fiction");
		Kid.registerAccount();
		Kid.requestBook();
		LibraryUser Adult = new AdultUser(30, "Kids");
		Adult.registerAccount();
		Adult.requestBook();
		Adult = new AdultUser(11, "Kids");
		Adult.registerAccount();
		Adult.requestBook();
		Adult = new AdultUser(30, "Fiction");
		Adult.registerAccount();
		Adult.requestBook();
	}

}
