var LocalDate = Java.type("java.time.LocalDate");
print(LocalDate.now());