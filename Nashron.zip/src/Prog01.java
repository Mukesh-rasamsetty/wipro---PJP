import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Prog01 {

	public static void main(String[] args) throws ScriptException, NoSuchMethodException {
		ScriptEngineManager engineManager = new ScriptEngineManager();
		ScriptEngine ee = engineManager.getEngineByName("Nashorn");
		ee.eval("E:\\WIPRO\\Nashorns\\src\\Demo.js");
		Invocable invocable = (Invocable)ee;
		if((boolean) invocable.invokeFunction("isPrime", "29"))
			System.out.println("Prime");
		else
			System.out.println("Not a Prime");
	}

}
