
public class Employee {
	private int EmpNo;
	private String name;
	private int age;
	private String location;
	public Employee(int empNo, String name, int age, String location) {
		EmpNo = empNo;
		this.name = name;
		this.age = age;
		this.location = location;
	}
	public int getEmpNo() {
		return EmpNo;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public String getLocation() {
		return location;
	}
	
}
