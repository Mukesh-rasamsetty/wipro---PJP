import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Prog03 {

	public static void main(String[] args) {
		List<Student> students = new ArrayList<>();
		students.add(new Student(533, "Mukesh",90));
		students.add(new Student(534, "Mansoor",95));
		students.add(new Student(535, "Nitish",92));
		students.add(new Student(532, "Lokesh",45));
		students.add(new Student(530, "Aditya",49));
		
		List<Student> passed = students.stream().filter(st-> st.getMark()>=50).collect(Collectors.toList());
		passed.forEach(st -> System.out.println("ID : "+st.getRollNo()+" | Name : "+st.getName()+" | Marks : "+st.getMark()));
	}

}
