import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Prog02 {

	public static void main(String[] args) {
		List<Employee> employees = new ArrayList<>();
		employees.add(new Employee(533, "Mukesh",21, "KVL"));
		employees.add(new Employee(534, "Mansoor",21, "PUNE"));
		employees.add(new Employee(535, "Nitish",21, "KVL"));
		employees.add(new Employee(532, "Lokesh",21, "ONG"));
		employees.add(new Employee(530, "Aditya",21, "PUNE"));
		
		List<Employee> puneEmp = employees.stream().filter(n -> n.getLocation().equals("PUNE")).collect(Collectors.toList());
		puneEmp.forEach(emp -> System.out.println("ID : "+emp.getEmpNo()+" | Name : "+emp.getName()+" | Age : "+emp.getAge()+" | Location : "+emp.getLocation()));
	}

}
