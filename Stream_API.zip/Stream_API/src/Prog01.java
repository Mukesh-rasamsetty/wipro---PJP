import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Prog01 {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		al.add(-5);
		al.add(-4);
		al.add(-3);
		al.add(-2);
		al.add(-1);
		al.add(0);
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(5);
		System.out.println("List of Elements : " + al);
		System.out.println("Negative Even Elements : ");
		List<Integer> negEven = al.stream().filter(n -> n < 0 && n % 2 == 0).collect(Collectors.toList());
		negEven.forEach(n -> System.out.println(n));
	}

}
