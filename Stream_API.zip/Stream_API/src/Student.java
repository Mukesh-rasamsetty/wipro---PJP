
public class Student {
	private String name;
	private int mark;
	private int rollNo;
	public Student(int rollNo,String name, int mark) {
		this.name = name;
		this.mark = mark;
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public int getMark() {
		return mark;
	}
	public int getRollNo() {
		return rollNo;
	}
	
}
