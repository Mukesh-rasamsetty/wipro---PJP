import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Prog02 {

	public static void main(String[] args) {
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			final String url = "jdbc:oracle:thin:@localhost:1521:Mukesh";
			final String username = "hr";
			final String password = "hr";
			Connection con = null;
			con =DriverManager.getConnection(url, username, password);
			if(con != null)
				System.out.println("Connection Established successfully");
			else
				System.out.println("Connection could  not be established");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
