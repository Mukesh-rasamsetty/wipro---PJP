package org.user.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.user.entity.User;

public class ListModel {

	public List<User> getList(DataSource dataSource) {
		List<User> list = new ArrayList<>();
		try {
			Connection con = dataSource.getConnection();
			Statement stmt = con.createStatement();
			String sql = "Select * from users";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				list.add(new User(rs.getInt("users_ID"), rs.getString("UserName"), rs.getString("Email")));
			}
			rs.close();
			stmt.close();
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

}
