package org.user.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.user.entity.User;

public class FormModel {

	public void addingUser(DataSource dataSource, User user) {
		try {
			Connection con = dataSource.getConnection();
			String sql = "Insert into users(UserName,Email) values(?,?)";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, user.getUserName());
			stmt.setString(2, user.getEmail());
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateUser(DataSource dataSource, User user) {
		try {
			Connection con = dataSource.getConnection();
			String sql = "UPDATE users SET UserName = ? , Email = ? where users_ID=?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, user.getUserName());
			stmt.setString(2, user.getEmail());
			stmt.setInt(3, user.getUserid());
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteUser(DataSource dataSource, int parseInt) {
		try {
			Connection con = dataSource.getConnection();
			String sql = "Delete From users where users_ID=?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, parseInt);
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
