package org.user.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import org.user.entity.User;
import org.user.model.FormModel;
import org.user.model.ListModel;

@WebServlet("/FormController")
public class FormController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Resource(name = "jdbc/project")
	private DataSource dataSource;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String from = request.getParameter("Form");
		switch (from) {
		case "Adding":
			new FormModel().addingUser(dataSource,new User(request.getParameter("username"), request.getParameter("Email")));
			ListingData(request, response);
			request.getRequestDispatcher("ListUser.jsp").forward(request, response);
			break;

		case "Updating":
			new FormModel().updateUser(dataSource,new User(Integer.parseInt(request.getParameter("ID")),request.getParameter("username"),request.getParameter("Email")));
			ListingData(request, response);
			request.getRequestDispatcher("ListUser.jsp").forward(request, response);
			break;
			
		case "deleteform":
			new FormModel().deleteUser(dataSource,Integer.parseInt(request.getParameter("id")));
			ListingData(request, response);
			request.getRequestDispatcher("ListUser.jsp").forward(request, response);
			break;

		default:
			request.getRequestDispatcher("error.jsp").forward(request, response);
			break;
		}

	}


	private void ListingData(HttpServletRequest request, HttpServletResponse response) {
		List<User> listUsers = new ArrayList<>();
		listUsers = new ListModel().getList(dataSource);
		request.setAttribute("listUsers", listUsers);
	}

}
