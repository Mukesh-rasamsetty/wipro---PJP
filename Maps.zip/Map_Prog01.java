import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class Map_Prog01 {
	HashMap<String, String> M1;

	public Map_Prog01() {
		M1 = new HashMap<>();
	}

	public HashMap<String, String> saveCountryCapital(String CountryName, String Captial) {
		M1.put(CountryName, Captial);
		return M1;
	}

	public String getCapital(String CountryName) {
		return M1.get(CountryName);
	}

	public String getCountry(String capital) {
		for (Entry<String, String> entry : M1.entrySet()) {
			if (entry.getValue().equals(capital))
				return entry.getKey();
		}
		return null;
	}

	public HashMap<String, String> Swap() {
		HashMap<String, String> M2 = new HashMap<>();
		for (Entry<String, String> entry : M1.entrySet()) {
			M2.put(entry.getValue(), entry.getKey());
		}
		return M2;
	}

	public ArrayList<String> List_of_Countries() {
		ArrayList<String> countries = new ArrayList<>();
		for (Entry<String, String> entry : M1.entrySet()) {
			countries.add(entry.getKey());
		}
		return countries;
	}

	public void Display(HashMap<String, String> M) {
		for (Entry<String, String> entry : M.entrySet())
			System.out.println(entry.getKey() + " : " + entry.getValue());
		System.out.println("*****************************************");
	}

	public static void main(String[] args) {
		Map_Prog01 map_Prog01 = new Map_Prog01();
		HashMap<String, String> hashMap = map_Prog01.saveCountryCapital("India", "Delhi");
		hashMap = map_Prog01.saveCountryCapital("Japan", "Tokyo");
		map_Prog01.Display(hashMap);
		System.out.println("Japan Capital : " + map_Prog01.getCapital("Japan"));
		System.out.println("************************************************");
		System.out.println("Delhi is in " + map_Prog01.getCountry("Delhi"));
		System.out.println("************************************************");
		hashMap = map_Prog01.Swap();
		map_Prog01.Display(hashMap);
		ArrayList<String> arr = map_Prog01.List_of_Countries();
		for (String cou : arr)
			System.out.println(cou);
	}

}
