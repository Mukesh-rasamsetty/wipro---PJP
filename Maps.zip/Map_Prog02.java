import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class Map_Prog02 {

	public boolean CheckKey(HashMap<Integer, String> map, int key) {
		for (Entry<Integer, String> entry : map.entrySet()) {
			if (entry.getKey() == key)
				return true;
		}
		return false;
	}

	public boolean CheckValue(HashMap<Integer, String> map, String value) {
		for (Entry<Integer, String> entry : map.entrySet()) {
			if (entry.getValue().equals(value))
				return true;
		}
		return false;
	}

	public void display(HashMap<Integer, String> map) {
		Iterator<Entry<Integer, String>> iterator = map.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<Integer,String> entry = iterator.next();
			System.out.println("Key : " + entry.getKey() + "\tValue : " + entry.getValue());
		}
	}

	public static void main(String[] args) {
		HashMap<Integer, String> hashMap = new HashMap<>();
		hashMap.put(1, "Mukesh");
		hashMap.put(2, "Manohar");
		hashMap.put(3, "Aditya");
		hashMap.put(4, "Mansoor");
		hashMap.put(5, "Mahesh");
		Map_Prog02 map_Prog02 = new Map_Prog02();
		if (map_Prog02.CheckKey(hashMap, 3))
			System.out.println("Found...!");
		else
			System.out.println("Not found...!");
		if (map_Prog02.CheckValue(hashMap, "Sulthan"))
			System.out.println("Found...!");
		else
			System.out.println("Not found...!");
		map_Prog02.display(hashMap);
	}

}
