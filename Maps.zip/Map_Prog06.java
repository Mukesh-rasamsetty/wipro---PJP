import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map.Entry;

public class Map_Prog06 {
	Hashtable<String, String> M1;

	public Map_Prog06() {
		M1 = new Hashtable<>();
	}

	public Hashtable<String, String> saveCountryCapital(String CountryName, String Captial) {
		M1.put(CountryName, Captial);
		return M1;
	}

	public String getCapital(String CountryName) {
		return M1.get(CountryName);
	}

	public String getCountry(String capital) {
		for (Entry<String, String> entry : M1.entrySet()) {
			if (entry.getValue().equals(capital))
				return entry.getKey();
		}
		return null;
	}

	public Hashtable<String, String> Swap() {
		Hashtable<String, String> M2 = new Hashtable<>();
		for (Entry<String, String> entry : M1.entrySet()) {
			M2.put(entry.getValue(), entry.getKey());
		}
		return M2;
	}

	public ArrayList<String> List_of_Countries() {
		ArrayList<String> countries = new ArrayList<>();
		for (Entry<String, String> entry : M1.entrySet()) {
			countries.add(entry.getKey());
		}
		return countries;
	}

	public void Display(Hashtable<String, String> hashMap) {
		for (Entry<String, String> entry : hashMap.entrySet())
			System.out.println(entry.getKey() + " : " + entry.getValue());
		System.out.println("*****************************************");
	}

	public static void main(String[] args) {
		Map_Prog06 map_Prog06 = new Map_Prog06();
		Hashtable<String, String> hashMap = map_Prog06.saveCountryCapital("India", "Delhi");
		hashMap = map_Prog06.saveCountryCapital("Japan", "Tokyo");
		map_Prog06.Display(hashMap);
		System.out.println("Japan Capital : " + map_Prog06.getCapital("Japan"));
		System.out.println("************************************************");
		System.out.println("Delhi is in " + map_Prog06.getCountry("Delhi"));
		System.out.println("************************************************");
		hashMap = map_Prog06.Swap();
		map_Prog06.Display(hashMap);
		ArrayList<String> arr = map_Prog06.List_of_Countries();
		for (String cou : arr)
			System.out.println(cou);
	}

}
