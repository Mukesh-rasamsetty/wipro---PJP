import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class Map_Prog03 {

	public static void main(String[] args) {
		HashMap<String,String> India = new HashMap<>();
		India.put("Andhra Pradesh", "Amaravathi");
		India.put("Telengana", "Hyderabad");
		India.put("Gujarat", "Gandhiji Nagar");
		
		Iterator<Entry<String, String>> iterator = India.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<String,String> entry = iterator.next();
			System.out.println("State : " + entry.getKey() + "\t\t=>\tCaptial : " + entry.getValue());
		}
	}

}
