import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class Map_Prog04 {

	public boolean CheckKey(HashMap<String, Integer> map, String key) {
		for (Entry<String, Integer> entry : map.entrySet()) {
			if (entry.getKey().equals(key))
				return true;
		}
		return false;
	}

	public boolean CheckValue(HashMap<String, Integer> map, int value) {
		for (Entry<String, Integer> entry : map.entrySet()) {
			if (entry.getValue() == value)
				return true;
		}
		return false;
	}

	public void display(HashMap<String, Integer> map) {
		Iterator<Entry<String, Integer>> iterator = map.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<String, Integer> entry = iterator.next();
			System.out.println("Name : " + entry.getKey() + "\tPhone Number : " + entry.getValue());
		}
	}

	public static void main(String[] args) {
		HashMap<String, Integer> hashMap = new HashMap<>();
		hashMap.put("Mukesh", 703224);
		hashMap.put("Prasunna", 9963351);
		Map_Prog04 map_Prog04  = new Map_Prog04();
		if (map_Prog04.CheckKey(hashMap, "Mukesh"))
			System.out.println("Found...!");
		else
			System.out.println("Not found...!");
		if (map_Prog04.CheckValue(hashMap, 70322))
			System.out.println("Found...!");
		else
			System.out.println("Not found...!");
		map_Prog04.display(hashMap);
	}

}
