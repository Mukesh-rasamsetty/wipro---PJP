//Initialize an integer array with ascii values and print the corresponding character values in a single row.

import java.util.Scanner;

class Program04  
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		System.out.print("Enter Ascii values : ");
		for(int i = 0 ; i < n; i++)
		{
			arr[i] = sc.nextInt();
		}
		for(int i = 0 ; i < n; i++)
		{
			System.out.print((char)arr[i]+"\t");
		}
		sc.close();
	}
}
