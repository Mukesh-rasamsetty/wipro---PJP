//Write a program to initialize an integer array with values and check if a given number is present in the array or not.

import java.util.Scanner;

class Program03 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter No of Elements : ");
		int n = sc.nextInt();
		System.out.print("Enter Array elements : ");
		int[] arr = new int[n];
		for(int i = 0 ; i < n; i++)
		{
			arr[i] = sc.nextInt();
		}
		System.out.print("Enter Search Element : ");
		int req = sc.nextInt();
		int flag = -1;
		for(int i =0 ;i < n ; i++)
		{
			if(arr[i] == req)
			{
				flag = i;
				break;
			}
		}
		System.out.println(flag);
		sc.close();
	}
}
