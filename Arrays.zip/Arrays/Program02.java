//Write a program to initialize an integer array and find the maximum and minimum value of the array.

import java.util.Scanner;
import java.util.Arrays;

class Program02
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0 ; i < n; i++)
		{
			arr[i] = sc.nextInt();
		}
		Arrays.sort(arr);
		System.out.println("Minimum : "+arr[0]+"\nMaximum : "+arr[n-1]);
		sc.close();
	}
}
