//Write a program to print the sum of the elements of an array following the given below condition.

//If the array has 6 and 7 in succeeding orders, ignore the numbers between 6 and 7 and consider the other numbers for calculation of sum.

import java.util.*;

class Program08
{
	public static int Search(int value,int[] arg)
	{
		for(int i=0 ; i<arg.length ;i++)
		{
			if(arg[i] == value)
				return i;
		}
		return -1;
	}
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0 ; i < n; i++)
		{
			arr[i] = sc.nextInt();
		}
		int sum =0;
		for(int i = 0 ; i < n ; i++)
		{
			if(arr[i] == 6)
			{
				int req = Search(7,arr);
				if(i < req)
				{
					i = req;
				}
				else
				{
					sum +=arr[i];
				}
			}
			else
			{
				sum += arr[i];
			}
		}
		System.out.println(sum);
		sc.close();
	}
}
