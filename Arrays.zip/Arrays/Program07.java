//Write a program to remove the duplicate elements in an array and print the same.

import java.util.*;

class Program07
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0 ; i < n; i++)
		{
			arr[i] = sc.nextInt();
		}
		for(int i = 0 ; i < n-1 ;i++)
		{
			for(int k = i+1; k < n ; k++ )
			{
				if(arr[i]==arr[k])
				{
					int j = k;
					while(j < n-1)
					{
						int temp = arr[j];
						arr[j] = arr[j+1];
						arr[j+1] = temp;
						j++;
					}
					n =n -1;
				}
			}
		}
		System.out.println("Array of elements after removing duplicates : ");
		for(int i = 0 ; i < n ; i++ )
			System.out.print(arr[i]+"\t");
		sc.close();
	}
}
