//Write a program to reverse the elements of a given 2*2 array. Four integer numbers needs to be passed as Command Line arguments.

class  Program09
{
	public static void main(String[] args) 
	{
		if(args.length!=4)
		{
			System.out.println("Please enter 4 integer numbers");
		}
		else
		{
			int index =0;
			System.out.println("The Given Array is :");
			for(int i = 0; i < 2; i++)
			{
				for(int j= 0; j <2 ; j++)
				{
					System.out.print(args[index]+"\t");
					index++;
				}
				System.out.println();
			}
			System.out.println("The reverse of the Array is :");
			for(int i = 0; i < 2; i++)
			{
				for(int j= 0; j <2 ; j++)
				{
					index--;
					System.out.print(args[index]+"\t");
				}
				System.out.println();
			}
		}
	}
}
