//Write a program to find the biggest number in a 3*3 array. The program is supposed to receive 9 integer numbers as command line arguments

class Program10 
{
	public static void main(String[] args) 
	{
		if(args.length!=9)
		{
			System.out.println("Please enter 9 integer numbers");
		}
		else
		{
			int index =0;
			int max = 0;
			System.out.println("The Given Array is :");
			for(int i = 0; i < 3; i++)
			{
				for(int j= 0; j <3 ; j++)
				{
					if(Integer.parseInt(args[index]) > max)
						max = Integer.parseInt(args[index]);
					System.out.print(args[index]+"\t");
					index++;
				}
				System.out.println();
			}
			System.out.println("The biggest number in the given Array is :"+max);
		}
	}
}
