// Write a program to find the largest 2 numbers and the smallest 2 numbers in the given array.

import java.util.Scanner;
import java.util.Arrays;

class Program05
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0 ; i < n; i++)
		{
			arr[i] = sc.nextInt();
		}
		Arrays.sort(arr);
		System.out.println("Largest Two Numbers : "+arr[n-2]+","+arr[n-1]+"\nSmallest Two Numbers : "+arr[0]+","+arr[1]);
		sc.close();
	}
}
