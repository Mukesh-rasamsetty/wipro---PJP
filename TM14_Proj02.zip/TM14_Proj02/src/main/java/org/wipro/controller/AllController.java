package org.wipro.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.wipro.model.Employee;
import org.wipro.services.EmployeeSerivce;

@Controller
public class AllController {
	
	@Autowired
	EmployeeSerivce service;

	@GetMapping("ListUsers")
	public ModelAndView listUsers() {
		List<Employee> list = service.getList();
		ModelAndView mv = new ModelAndView("list");
		mv.addObject("data", list);
		return mv;
	}
	
	@GetMapping("PreAdd")
	public ModelAndView preAdd() {
		ModelAndView mv = new ModelAndView("add");
		Employee employee = new Employee();
		mv.addObject("employee", employee);
		return mv;
	}
	
	@PostMapping("AddEmployee")
	public ModelAndView addEmployee(@Valid @ModelAttribute("employee") Employee employee,BindingResult result) {
		ModelAndView mv = new ModelAndView("list");
		if(result.hasErrors()) {
			ModelAndView mv1 = new ModelAndView("add");
			mv.addObject("employee", employee);
			return mv1;
		}
		service.addEmployee(employee);
		List<Employee> list = service.getList();
		mv.addObject("data", list);
		return mv;
	}
	
	@GetMapping("Search")
	public String search() {
		return "search";
	}
	
	@PostMapping("GetEmployee")
	public ModelAndView getEmployee(@RequestParam("id") String id) {
		ModelAndView mv = new ModelAndView("listById");
		int i = Integer.parseInt(id);
		Employee employee = service.getListById(i);
		if(employee == null)
			return new ModelAndView("error");
		mv.addObject("employee", employee);
		return mv;
	}
	
	@GetMapping("UpdateEmployee")
	public ModelAndView updateEmployee(@RequestParam("id") String id)
	{
		ModelAndView mv = new ModelAndView("update");
		Employee employee = service.getListById(Integer.parseInt(id));
		mv.addObject("employee", employee);
		return mv;
	}
	
	@PostMapping("Update")
	public ModelAndView update(@Valid @ModelAttribute("employee") Employee employee, BindingResult result)
	{
		ModelAndView mv = new ModelAndView("list");
		if(result.hasErrors())
		{
			ModelAndView mv1 = new ModelAndView("update");
			mv.addObject("employee", employee);
			return mv1;
		}
		service.updateEmployee(employee);
		List<Employee> list = service.getList();
		mv.addObject("data", list);
		return mv;
	}
	
	@GetMapping("DeleteEmployee")
	public ModelAndView deleteEmployee(@RequestParam("id") String id)
	{
		service.deleteEmployee(Integer.parseInt(id));
		ModelAndView mv = new ModelAndView("list");
		List<Employee> data = service.getList();
		mv.addObject("data", data);
		return mv;
	}
	
}
