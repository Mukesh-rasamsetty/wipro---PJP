package org.wipro.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.wipro.model.Employee;

/*
 * @Transactional
 * @Repository
 */
public class EmployeeDAO {

	// @Autowired
	SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class)
			.buildSessionFactory();

	/*
	 * @Autowired HibernateTemplate template;
	 */

	@SuppressWarnings("unchecked")
	public List<Employee> getList() {
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		List<Employee> list = session.createQuery("from employee").getResultList();
		session.getTransaction().commit();
		session.close();
		return list;
	}

	public Employee getListById(int id) {
		/*
		 * Employee emp = template.load(Employee.class, id); return emp;
		 */
		try{Session session = factory.getCurrentSession();
		session.beginTransaction();
		Employee list = session.get(Employee.class, id);
		session.getTransaction().commit();
		session.close();
		return list;}
		catch (Exception e) {
			return null;
		}
	}

	public void addEmployee(Employee e) {
		/*
		 * Session session = factory.openSession(); session.save(e);
		 */
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		session.save(e);
		session.getTransaction().commit();
		session.close();
	}

	public void deleteEmployee(int id) {
		/* template.delete(getListById(id)); */
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		session.delete(session.get(Employee.class, id));
		session.getTransaction().commit();
		session.close();
	}

	public void updateEmployee(Employee e) {
		/*
		 * Session session = factory.openSession(); session.saveOrUpdate(e);
		 */
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		session.saveOrUpdate(e);
		session.getTransaction().commit();
		session.close();
	}
}
