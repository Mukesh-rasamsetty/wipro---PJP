package org.wipro.services;

import java.util.List;

import org.springframework.stereotype.Service;
import org.wipro.DAO.EmployeeDAO;
import org.wipro.model.Employee;

@Service
public class EmployeeSerivce {

	private EmployeeDAO dao = new EmployeeDAO();
	
	public List<Employee> getList() {
		return dao.getList();
	}
	
	public Employee getListById(int id) {
		return dao.getListById(id);
	}

	public void addEmployee(Employee e) {
		dao.addEmployee(e);
	}

	public void deleteEmployee(int id) {
		dao.deleteEmployee(id);
	}

	public void updateEmployee(Employee e1) {
		dao.updateEmployee(e1);
	}
}