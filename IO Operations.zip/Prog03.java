import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map.Entry;
import java.util.TreeMap;

public class Prog03 {
	
	public static void main(String[] args) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(args[0])));
			String st ="";
			String str;
			while((str = br.readLine()) != null)
			{
				st = st +str+" ";
			}
			br.close();
			String[] words  = st.split(" ");
			TreeMap<String, Integer> map = new TreeMap<>();
			for(int i = 0; i <words.length; i++) {
				boolean flag = true;
				for(Entry<String,Integer> entry : map.entrySet()) {
					if(entry.getKey().equals(words[i]))
					{
						entry.setValue(entry.getValue()+1);
						flag =false;
					}
				}
				if(flag)
					map.put(words[i], 1);
			}
			FileWriter fileWriter = new FileWriter(args[1],false);
			fileWriter.write(32);
			fileWriter.close();
			fileWriter = new FileWriter(args[1],true);
			fileWriter.flush();
			for(Entry<String, Integer> entry : map.entrySet()) {
				fileWriter.write(entry.getKey()+" : "+entry.getValue()+"\n");
			}
			fileWriter.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
