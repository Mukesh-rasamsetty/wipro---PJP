import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Prog02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the input file name");
		String input = sc.nextLine();
		System.out.println("Enter the output file name");
		String output = sc.nextLine();
		try {
			FileInputStream fileInputStream = new FileInputStream(input);
			FileOutputStream fileOutputStream = new FileOutputStream(output);
			int c;
			while((c = fileInputStream.read()) != -1)
			{
				fileOutputStream.write(c);
			}
			System.out.println("file is copied");
		} catch (FileNotFoundException e) {
			System.out.println("File not found...!");
		} catch (IOException e) {
			System.out.println("IO Exception");
		}
		sc.close();
	
	}

}
