import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Prog01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the file name");
		String filename = sc.nextLine();
		System.out.println("Enter the character to be counted");
		char ch = sc.next().charAt(0);
		int counter = 0;
		try {
			FileInputStream fileInputStream = new FileInputStream(filename);
			int c;
			while((c = fileInputStream.read()) != -1)
			{
				if(c == ch)
				{
					counter++;
				}
			}
			System.out.println(counter);
		} catch (FileNotFoundException e) {
			System.out.println("File not found...!");
		} catch (IOException e) {
			System.out.println("IO Exception");
		}
		sc.close();
	}

}
