
public class Proj1 {

	public static void main(String[] args) {
		String[][] employee = { { "1001", "Ashish", "01/04/2009", "e", "R&D", "20000", "8000", "3000" },
				{ "1002", "Sushma", "23/08/2012", "c", "PM", "30000", "12000", "9000" },
				{ "1003", "Rahul", "12/11/2008", "k", "Acct", "10000", "8000", "1000" },
				{ "1004", "Chahat", "29/01/2013", "r", "Front Desk", "12000", "6000", "2000" },
				{ "1005", "Ranjan", "16/07/2005", "m", "Engg", "50000", "20000", "20000" },
				{ "1006", "Suman", "1/1/2000", "e", "Manufacturing", "23000", "9000", "4400" },
				{ "1007", "Tanmay", "12/06/2006", "c", "PM ", "29000", "12000", "10000" } };

		String[][] Dearness = { { "e", "Engineer", "20000" }, { "c", "Consultant", "32000" }, { "k", "Clerk", "12000" },
				{ "r", "Receptionist", "15000" }, { "m ", " Manager", "40000" } };
		if (args.length == 1) {
			String[] result = new String[5];
			boolean flag = false;
			for (int i = 0; i < 7; i++) {
				if (args[0].equals(employee[i][0])) {
					flag = true;
					result[0] = employee[i][0];
					result[1] = employee[i][1];
					result[2] = employee[i][4];
					result[3] = employee[i][3];
					result[4] = String.valueOf(Integer.parseInt(employee[i][5]) + Integer.parseInt(employee[i][6])
							- Integer.parseInt(employee[i][7]));
				}
			}
			if (flag) {
				for (int i = 0; i < 5; i++) {
					if(result[3].equals(Dearness[i][0]))
					{
						result[3] = Dearness[i][1];
						result[4] = String.valueOf(Integer.parseInt(result[4])+Integer.parseInt(Dearness[i][2]));
						break;
					}
				}
				System.out.println("Emp No.\tEmp Name\tDepartment\tDesignation\tSalary");
				System.out.println(result[0]+"\t"+result[1]+"\t\t"+result[2]+"\t\t"+result[3	]+"\t\t"+result[4]);
			} else {
				System.out.println("There is no employee with empid : " + args[0]);
			}
		}
	}

}
