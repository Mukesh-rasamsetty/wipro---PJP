
public interface DigitCount {
	int digitCount(int n);
}
