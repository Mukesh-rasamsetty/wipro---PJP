
public class Prog03 {
	Prog03(int n){
		boolean flag = true;
		for(int i = 2; i < n ; i++)
			if(n %  i == 0)
				flag = false;
		if(flag)
			System.out.println("Prime");
		else
			System.out.println("Not a Prime");
	}
	
	public static void main(String[] args) {
		Con_Interface con = Prog03 :: new ;
		con.IsPrime(29);
	}
}
