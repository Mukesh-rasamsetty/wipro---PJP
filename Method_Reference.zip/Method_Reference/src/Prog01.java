
public class Prog01 {

	public int factorial(int n) {
		if(n == 1)
			return 1;
		return n*factorial(n-1);
	}
	
	public static void main(String[] args) {
		Prog01 prog01 = new Prog01();
		Fact fact = prog01 :: factorial;
		System.out.println(fact.fact(6));
	}

}
