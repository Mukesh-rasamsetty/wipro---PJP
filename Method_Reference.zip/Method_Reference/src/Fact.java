
public interface Fact {
	public int fact(int n);
}
