
public class Prog02 {
	public static int DigitsCount(int n) {
		int count = 0;
		while(n > 0) {
			count++;
			n /= 10;
		}
		return count;
	}
	public static void main(String[] args) {
		DigitCount dCount = Prog02 :: DigitsCount;
		System.out.println(dCount.digitCount(12345));
	}

}
