
public interface Con_Interface {
	Prog03 IsPrime(int n);
}
