import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;

public class SerialDemo {

	public static void main(String[] args) {
		Employee emp = new Employee("Mukesh", "CSE", "B.Tech", 400000, new Date(1999, 8, 10));
		SerialDemo.Display(emp);
		try {
			FileOutputStream fout = new FileOutputStream("Data.txt");
			ObjectOutputStream objout = new ObjectOutputStream(fout);
			objout.writeObject(emp);
			objout.close();
			fout.close();
			FileInputStream fin = new FileInputStream("Data.txt");
			ObjectInputStream in = new ObjectInputStream(fin);
			Employee e = (Employee) in.readObject();
			in.close();
			fin.close();
			SerialDemo.Display(e);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

	private static void Display(Employee emp) {
		System.out.println("Employee Details :\n=============================");
		System.out.println("Name : "+emp.getName()+"\nDepartment : "+emp.getDepartment()+"\nDesignation : "+emp.getDesignation()+"\nSalary : "+emp.getSalary()+"\nDate :"+emp.getDob().getDate()+" - "+emp.getDob().getMonth()+" - "+emp.getDob().getYear());
		System.out.println("***********************************************");
	}

}
