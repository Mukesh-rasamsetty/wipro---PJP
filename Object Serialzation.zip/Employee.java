import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable{
	private String name, department, designation;
	private double Salary;
	Date dob;
	
	public Employee(String name, String department, String designation, double salary, Date dob) {
		this.name = name;
		this.department = department;
		this.designation = designation;
		Salary = salary;
		this.dob = dob;
	}
	
	public Employee() {
		name = null;
		department = null;
		designation = null;
		Salary = 0.0;
		dob = null;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getSalary() {
		return Salary;
	}

	public void setSalary(double salary) {
		Salary = salary;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	
}
