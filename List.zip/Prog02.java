
public class Prog02 {

	public static void main(String[] args) {
		EmployeeDB employeeDB = new EmployeeDB();
		Employee employee = new Employee(530, "Mukesh", "rasamsettymukesh@gmail.com", "Male", 50000);
		employeeDB.addEmployee(employee);
		employee.GetEmployeeDetails();
		System.out.println(employeeDB.showPaySlip(530));
		if(employeeDB.deleteEmployee(533))
			System.out.println("533 is deleted successfully...!");
		else
			System.out.println("533  not found..!");
	}

}
