
public class Employee {
	public int empid;
	public String empname, email, gender;
	public float salary;
	
	public Employee(int empid, String empname, String email, String gender, float salary) {
		this.empid = empid;
		this.empname = empname;
		this.email = email;
		this.gender = gender;
		this.salary = salary;
	}
	
	public void GetEmployeeDetails()
	{
		System.out.println("Employee Details");
		System.out.println("================");
		System.out.println("ID: "+empid);
		System.out.println("Name: "+empname);
		System.out.println("EMail: "+email);
		System.out.println("Gender: "+gender);
		System.out.println("Salary: "+salary);
	}
}
