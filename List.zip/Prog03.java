import java.util.ArrayList;
import java.util.Iterator;

public class Prog03 {
	ArrayList<String> arrayList;
	
	public Prog03() {
		arrayList = new ArrayList<>();
	}
	
	public void printAll() {
		Iterator<String> iterator = arrayList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
	
	public static void main(String[] args) {
		Prog03 prog03 = new Prog03();
		prog03.arrayList.add("Mukesh");
		prog03.arrayList.add("Manohar");
		prog03.arrayList.add("Aditya");
		prog03.arrayList.add("Prasunna");
		prog03.arrayList.add("Malakondaiah");
		prog03.printAll();
	}
}
