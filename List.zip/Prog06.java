import java.util.Vector;

public class Prog06 {
	public static void main(String[] args) {
		Vector<String> list = new Vector<String>();
		list.add("January");
		list.add("Febuary");
		list.add("March");
		list.add("April");
		list.add("May");
		list.add("June");
		list.add("May");
		list.add("July");
		list.add("August");
		list.add("September");
		list.add("October");
		list.add("November");
		list.add("December");
		for( String month : list) {
			System.out.println(month);
		}
	}
}
