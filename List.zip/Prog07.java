import java.util.Vector;

public class Prog07 {
Vector<Employee> empList;
	
	public Prog07() {
		empList = new Vector<>();
	}
	
	public boolean addEmployee(Employee e)
	{
		empList.add(e);
		return true;
	}
	
	public boolean deleteEmployee(int empId) {
		for(Employee e : empList) {
			if(e.empid == empId)
			{
				empList.remove(e);
				return true;
			}
		}
		return false;
	}
	
	public String showPaySlip(int empId) {
		for(Employee e : empList) {
			if(e.empid == empId)
			{
				return String.valueOf(e.salary);
			}
		}
		return "NONE";
	}

	public static void main(String[] args) {
		Prog07 prog = new Prog07();
		Employee employee = new Employee(530, "Mukesh", "rasamsettymukesh@gmail.com", "Male", 50000);
		prog.addEmployee(employee);
		employee.GetEmployeeDetails();
		System.out.println(prog.showPaySlip(530));
		if(prog.deleteEmployee(533))
			System.out.println("533 is deleted successfully...!");
		else
			System.out.println("533  not found..!");
	}

}
