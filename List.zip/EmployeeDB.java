import java.util.ArrayList;

public class EmployeeDB {
	ArrayList<Employee> empList;
	
	public EmployeeDB() {
		empList = new ArrayList<>();
	}
	
	public boolean addEmployee(Employee e)
	{
		empList.add(e);
		return true;
	}
	
	public boolean deleteEmployee(int empId) {
		for(Employee e : empList) {
			if(e.empid == empId)
			{
				empList.remove(e);
				return true;
			}
		}
		return false;
	}
	
	public String showPaySlip(int empId) {
		for(Employee e : empList) {
			if(e.empid == empId)
			{
				return String.valueOf(e.salary);
			}
		}
		return "NONE";
	}
}
