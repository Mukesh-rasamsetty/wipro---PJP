import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Prog04 {
ArrayList<Number> arrayList;
	
	public Prog04() {
		arrayList = new ArrayList<>();
	}
	
	public void printAll() {
		Iterator<Number> iterator = arrayList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			Prog04 prog04 = new Prog04();
			prog04.arrayList.add(10);
			prog04.arrayList.add(10.25);
			prog04.arrayList.add(10.25f);
			prog04.printAll();
		} catch (NumberFormatException e) {
			System.out.println("ONly Numbers ..!");
		}
	}
}
