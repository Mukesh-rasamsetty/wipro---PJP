import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class EmpProg {

	Connection conn;

	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:Mukesh";
			String username = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, username, password);
			if (conn != null)
				System.out.println("Connection established...!");
			else
				System.out.println("Something went Wrong in Connecting...!");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found in Connect Method...!");

		} catch (SQLException e) {
			System.out.println("SQL Exception in Connect Method...!");
		}
	}

	public double getSalary(String n) {
		double net = 0;
		try {
			Statement stmt = conn.createStatement();
			String sql = "SELECT SALARY,COMMISSION FROM EMP WHERE EMPNO =" + n;
			ResultSet rs = stmt.executeQuery(sql);
			int gross_salary = 0;
			int comm = 0;
			while (rs.next()) {
				gross_salary = rs.getInt("SALARY") + rs.getInt("COMMISSION");
				comm = rs.getInt("COMMISSION");
			}
			double IT = 0;
			if (comm == 0) {
				IT = gross_salary * 0.10;
			} else if (comm < 500)
				IT = gross_salary * 0.15;
			else
				IT = gross_salary * 0.20;
			net = gross_salary - IT;
		} catch (Exception e) {
			System.out.println("Exception in Gross salary");
		}
		return net;
	}

	public void disconnect() {
		try {
			conn.close();
			System.out.println("Disconnected Successfully....!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void display(String n, double net) {
		try {
			Statement stmt = conn.createStatement();
			String sql = " SELECT SALARY,COMMISSION FROM EMP WHERE EMPNO = " + n;
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				System.out.println("Employee Details");
				System.out.println("================");
				System.out.println("Number 	   : " + rs.getInt("EMPNO"));
				System.out.println("Name       : " + rs.getString("NAME"));
				System.out.println("Net Salary : " + net);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter roll number of employee : ");
		String n = String.valueOf(sc.nextInt());
		EmpProg empProg = new EmpProg();
		empProg.connect();
		double gross = empProg.getSalary(n);
		empProg.display(n, gross);
		empProg.disconnect();
		sc.close();
	}

}
