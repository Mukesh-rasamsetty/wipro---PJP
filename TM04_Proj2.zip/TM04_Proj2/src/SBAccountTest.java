import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SBAccountTest {
	SBAccount NRI = new SBAccount(100000, "NRI");
	SBAccount Normal = new SBAccount(100000, "Normal");
	@Test
	void testCalculateInterest() {
		assertEquals(4000, Normal.calculateInterest());
		assertEquals(6000, NRI.calculateInterest());
	}

	@Test
	void testGetInterest() {
		assertEquals(4.0, Normal.getInterest());
		assertEquals(6.0, NRI.getInterest());
	}

}
