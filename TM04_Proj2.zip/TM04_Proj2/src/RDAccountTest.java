import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RDAccountTest {
	
	RDAccount RD1 = new RDAccount(100000, 7, 30);
	RDAccount RD2 = new RDAccount(100000, 7, 60);
	
	@Test
	void testCalculateInterest() {
		assertEquals(7750, RD1.calculateInterest());
		assertEquals(8250, RD2.calculateInterest());
	}

	@Test
	void testGetInterset() {
		assertEquals(7.75, RD1.getInterset());
		assertEquals(8.25, RD2.getInterset());
	}

}
