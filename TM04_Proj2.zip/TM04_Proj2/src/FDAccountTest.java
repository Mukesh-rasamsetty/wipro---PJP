import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FDAccountTest {
	
	FDAccount FD1 = new FDAccount(10000,91,34);
	FDAccount FD2 = new FDAccount(10000, 91, 65);
	
	@Test
	void testCalculateInterest() {
		assertEquals(750, FD1.calculateInterest());
		assertEquals(800, FD2.calculateInterest());
	}

	@Test
	void testGetInterset() {
		assertEquals(7.50, FD1.getInterset());
		assertEquals(8.0, FD2.getInterset());
	}

}
