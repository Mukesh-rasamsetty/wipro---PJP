
public abstract class Account {
	public double amount;

	public Account(double amount) {
		this.amount = amount;
	}

	abstract public double calculateInterest();
}
