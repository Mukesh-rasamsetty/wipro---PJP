import java.util.HashSet;

public class BoxList {
	HashSet<BoxDetails> list;

	public BoxList() {
		list = new HashSet<>();
	}

	public void insert(BoxDetails box) {
		boolean flag = true;
		if (list.isEmpty()) {
			list.add(box);
		} else {
			for (BoxDetails b : list) {
				if (b.getLength() == box.getLength() && b.getHeight() == box.getHeight()
						&& b.getWidth() == box.getWidth()) {
					flag = false;
					break;
				}
			}
			if (flag)
				list.add(box);
		}
	}

	public void display() {
		System.out.println("Unique Boxes in the Set are ");
		for (BoxDetails b : list) {
			System.out.println("Length =" + b.getLength() + " Width =" + b.getWidth() + " Height =" + b.getHeight()+" Volume =" + String.format("%.2f", (b.getLength() * b.getHeight() * b.getWidth())));
		}
	}
}
