import java.util.Scanner;

public class TestBoxMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Box");
		int n = sc.nextInt();
		BoxList boxList = new BoxList();
		for(int i = 0 ; i < n ; i ++)
		{
			System.out.println("Enter the Box "+(i+1)+" details ");
			System.out.println("Enter Length");
			double length = sc.nextDouble();
			System.out.println("Enter Width");
			double width = sc.nextDouble();
			System.out.println("Enter Height");
			double height = sc.nextDouble();
			boxList.insert(new BoxDetails(length, width, height));
		}
		boxList.display();
		sc.close();
	}

}
