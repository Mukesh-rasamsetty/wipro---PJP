import java.util.Scanner;

public class String_Prog04 {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		int n = str.length();
		if(n  % 2 == 0)
		{
			for(int i = 0 ; i < n/2 ; i++)
			{
				System.out.print(str.charAt(i));
			}
		}
		else
			System.out.println("null");
		sc.close();
	}
}
