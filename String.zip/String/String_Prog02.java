import java.util.Scanner;

public class String_Prog02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] str = sc.nextLine().split(" ");
		String str1= str[0].toLowerCase();
		String str2 = str[1].toLowerCase();
		if(str1.charAt(str1.length()-1) == str2.charAt(0))
		{
			for(int i = 1 ; i < str2.length(); i++)
			{
				str1 += str2.charAt(i);
			}
		}
		else
		{
			str1 = str1+" ";
			for(int i = 0 ; i < str2.length(); i++)
			{
				str1 += str2.charAt(i);
			}
		}
		System.out.println(str1);
		sc.close();
	}

}
