import java.util.Scanner;

public class String_Prog06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str[] = sc.nextLine().split(" ");
		if (str.length == 2) {
			String str1 = str[0];
			String str2 = str[1];
			if (str1.length() > str2.length()) {
				System.out.print(str2);
				System.out.print(str1);
				System.out.print(str2);
			} else {
				System.out.print(str1);
				System.out.print(str2);
				System.out.print(str1);
			}
		} else {
			System.out.println(str[0]);
		}
		sc.close();
	}

}
