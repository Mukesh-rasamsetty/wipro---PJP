import java.util.Scanner;

public class String_Prog03 {

	public static void main(String[] args) {
		Scanner Sc = new Scanner(System.in);
		String str = Sc.nextLine();
		int n = str.length();
		String str1 = "";
		str1 = str1 + str.charAt(0) + str.charAt(1);
		for (int i = 0; i < n; i++) {
			System.out.print(str1);
		}
		Sc.close();
	}

}
