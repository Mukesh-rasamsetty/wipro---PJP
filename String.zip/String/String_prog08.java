import java.util.Scanner;

public class String_prog08 {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		if(str.contains("*"))
		{
			int n = str.indexOf("*");
			System.out.println(str.substring(0,n)+str.substring(n+1));
		}
		else
		{
			System.out.println("Enter string with '*' symbol");
		}
		sc.close();
	}
}
