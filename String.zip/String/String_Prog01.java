import java.util.Scanner;

public class String_Prog01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		boolean flag = true;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) != str.charAt(str.length() - 1 - i)) {
				flag = !flag;
				break;
			}
		}
		if (flag)
			System.out.println("Palindrome");
		else
			System.out.println("Not a Palindrome");
			sc.close();
	}

}
