import java.util.Scanner;

public class String_Prog11 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		String[] str = sc.nextLine().split(",");
		String str1 = str[0];
		String str2 = str[1];
		int i =0;
		String result = "";
		while(i< str1.length())
		{
			if(str1.charAt(i) == str2.charAt(0))
			{
				boolean flag= true;
				for(int j =0; j<str2.length(); j++)
				{
					if(i+j < str1.length() && str2.charAt(j)!=str1.charAt(i+j) )
					{
						flag = false;
					}
				}
				if(flag)
				{
					if(i>0)
					{
						result = result + str1.charAt(i-1);
					}
					if(i+str2.length() != str1.length())
					{
						result = result + str1.charAt(i+str2.length());
					}
					i = i + str2.length();
				}
				else
					i++;
			}
			else
			{
				i++;
			}
		}
		System.out.println(result);
		sc.close();
	}

}
