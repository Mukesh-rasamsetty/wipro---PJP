import java.util.Scanner;

public class String_prog09 {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String[] str = sc.nextLine().split(",");
		String result = "";
		int i;
		for(i =0 ; i<str[0].length() && i < str[1].length() ; i++)
		{
			result = result+ str[0].charAt(i)+str[1].charAt(i);
		}
		if(str[0].length() > i)
		{
			result = result+str[0].substring(i);
		}
		else
			result = result +str[1].substring(i);
		System.out.println(result);
		sc.close();
	}
}
