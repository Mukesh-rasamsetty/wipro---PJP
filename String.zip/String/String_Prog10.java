import java.util.Scanner;

public class String_Prog10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		int n = sc.nextInt();
		str = str.substring(str.length()-n);
		for(int i =0 ; i < n ; i++)
			System.out.print(str);
		sc.close();
	}

}
