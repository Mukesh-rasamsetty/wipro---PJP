import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class VideoStoreTest {

	VideoStore Videostore = new VideoStore();
	
	@Test
	void testAddVideo() {
		assertTrue(Videostore.addVideo("War"));
	}

	@Test
	void testDoCheckout() {
		assertFalse(Videostore.doCheckout("War"));
	}

	@Test
	void testDoReturn() {
		assertTrue(Videostore.doReturn("War"));
	}

	@Test
	void testReceiveRating() {
		assertEquals(-1, Videostore.receiveRating("War", 10));
	}

}
