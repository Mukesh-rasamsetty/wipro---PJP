import java.util.LinkedList;

public class VideoStore {
	public LinkedList<Video> store;
	int i = 0 ;

	public VideoStore() {
		store = new LinkedList<>();
	}

	public boolean addVideo(String name) {
		store.add(new Video(name));
		System.out.println("Video \""+name+"\" added successfully.");
		return true;
	}

	public boolean doCheckout(String name) {
		for (Video videoname : store) {
			System.out.println(videoname.getName());
			if (videoname.getName().equals(name)) {
				videoname.doCheckout();
				System.out.println("Video \""+name+"\" checked out successfully.");
				return videoname.getCheckout();
			}
		}
		return false;
	}

	public boolean doReturn(String name) {
		for (Video videoname : store) {
			if (videoname.getName().equals(name)) {
				videoname.doReturn();
				System.out.println("Video \""+name+"\" returned successfully.");
				return videoname.getCheckout();
			}
		}
		return true;
	}

	public int receiveRating(String name, int rating) {
		for (Video videoname : store) {
			if (videoname.getName().equals(name)) {
				videoname.receiveRating(rating);
				System.out.println("Rating \""+rating+"\" has been mapped to the Video \""+name+"\".");
				return videoname.getRating();
			}
		}
		return -1;
	}

	public void listInventory() {
		System.out.println("---------------------------------------------------------------------");
		System.out.println("Video Name\t|\tCheckout Status\t|\tRating");
		for (Video videoname : store) {
			System.out.println(videoname.getName() + "\t\t|\t" + videoname.getCheckout() + "\t\t|\t" + videoname.getRating());
		}
		System.out.println("---------------------------------------------------------------------");
	}
}
