import java.util.Scanner;

public class VideoLauncher {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		VideoStore videoStore = new VideoStore();
		abc: while (true) {
			System.out.println("MAIN MENU");
			System.out.println("=========");
			System.out.println(
					"1.Add Videos :\n2.Check Out Video :\n3.Return Video :\n4.Receive Rating :\n5.List Inventory :\n6.Exit :");
			System.out.print("Enter your choice (1..6): ");
			int ch = sc.nextInt();
			String str;
			switch (ch) {
			case 1:
				System.out.print("Enter the name of the video you want to add: ");
				str = sc.next();
				videoStore.addVideo(str);
				break;
			case 2:
				System.out.print("Enter the name of the video you want to check out: ");
				str = sc.next();
				videoStore.doCheckout(str);
				break;
			case 3:
				System.out.print("Enter the name of the video you want to Return: ");
				str = sc.next();
				videoStore.doReturn(str);
				break;
			case 4:
				System.out.print("Enter the name of the video you want to Rate: ");
				str = sc.next();
				System.out.print("Enter the rating for this video: ");
				int rating = sc.nextInt();
				videoStore.receiveRating(str, rating);
				break;
			case 5:
				videoStore.listInventory();
				break;
			case 6:
				break abc;
			default:
				System.out.println("Enter valid option between 1 and 6.........!");
				break;
			}
		}
		sc.close();
	}

}
