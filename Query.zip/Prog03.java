import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Prog03 {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			final String url = "jdbc:oracle:thin:@localhost:1521:Mukesh";
			final String username = "hr";
			final String password = "hr";
			Connection con = null;
			con =DriverManager.getConnection(url, username, password);
			Statement stmt = con.createStatement();
			String sql = "SELECT LAST_NAME FROM EMPLOYEES";
			ResultSet resultSet = stmt.executeQuery(sql);
			int i = 0;
			System.out.println("Employee table........!\nEMPNO\t\t\tENAME\n======================================");
			while(resultSet.next())
			{
				i++;
				System.out.print(i+"\t\t\t");
				System.out.println(resultSet.getString("last_name"));
			}
			con.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
