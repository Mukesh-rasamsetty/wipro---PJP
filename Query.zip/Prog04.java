import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Prog04 {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			final String url = "jdbc:oracle:thin:@localhost:1521:Mukesh";
			final String username = "hr";
			final String password = "hr";
			Connection con = null;
			con =DriverManager.getConnection(url, username, password);
			Statement stmt = con.createStatement();
			String sql = "SELECT Last_name,Job_id,salary,COMMISSION_PCT FROM EMPLOYEES WHERE SALARY >= 10000 AND SALARY <= 20000";
			ResultSet resultSet = stmt.executeQuery(sql);
			System.out.println("Employee table........!\nENAME\tJOB\tSALARY\tCOMMISSION\n==============================================");
			while(resultSet.next())
			{
				System.out.println(resultSet.getString("last_name")+"\t\t"+resultSet.getString("job_id")+"\t\t"+resultSet.getInt("Salary")+"\t\t"+resultSet.getInt("COMMISSION_PCT"));
			}
			con.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
