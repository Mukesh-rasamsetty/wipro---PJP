
public class Prog04 {

	public static void main(String[] args) {
		Employee emp = new Employee("Mukesh", 1000000);
		try {
			System.out.println("Before Clone.............!");
			emp.display();
			Employee empclone = (Employee) emp.clone();
			System.out.println("After Clone...............!");
			empclone.display();
			System.out.println("Values Updated with Clone reference........!");
			empclone.updateSalary(1000000000);
			empclone.display();
			emp.display();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
