
public class Prog02 {

	public static void main(String[] args) {
		try {
			System.out.println("Given Number :" + args[0]);
			System.out.println("Binary equivalent :" + Integer.toBinaryString(Integer.parseInt(args[0])));
			System.out.println("Octal equivalent :" + Integer.toOctalString(Integer.parseInt(args[0])));
			System.out.println("Hexadecimal equivalent :" + Integer.toHexString(Integer.parseInt(args[0])));
		} catch (NumberFormatException e) {
			System.out.println("Enter Numbers only...!");
		}
	}
}
