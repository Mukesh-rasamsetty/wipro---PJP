import java.util.Scanner;

public class Prog03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		try {
			if (n > 0 && n < 256) {
				String binary = Integer.toBinaryString(n);
				int len = binary.length();
				while (len < 8) {
					binary = 0 + binary;
					len++;
				}
				System.out.println(binary);
			} else
				throw new NumberFormatException();
		} catch (NumberFormatException e) {
			System.out.println("Number should be between 1 and 255...!");
		}
		sc.close();
	}

}
