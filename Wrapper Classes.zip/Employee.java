
public class Employee implements Cloneable {
	String name;
	double salary;
	
	public Employee(String name, double salary)
	{
		this.salary = salary;
		this.name = name;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public void updateSalary(double salary)
	{
		this.salary = salary;
	}
	
	public void display()
	{
		System.out.println("Employee Name: "+name+"\nAnnual Salary: "+salary);
	}
}
