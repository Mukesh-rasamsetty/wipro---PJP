import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyFirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
	}

	public void doGet( HttpServletRequest request,HttpServletResponse response ) throws    ServletException,IOException
	 {
	  response.setContentType("text/html");
	  PrintWriter out=response.getWriter();
	  out.println("<HTML>" + 
	     "" +
	     "<body bgcolor=YellowGreen>");
	     
	  out.println("Request method:" + request.getMethod() + "<br><br>");
	  out.println("Request URI:" + request.getRequestURI() + "<br><br>");
	  out.println("Request protocol:" + request.getProtocol() + "<br><br>");
	  out.println("<table border=1 align=left><tr><th>Header Name</th><th>Header Value</th></tr>");
	  Enumeration<String> headerNames=request.getHeaderNames();
	  while(headerNames.hasMoreElements())
	  {
	   String headerName=(String)headerNames.nextElement();
	   out.println("<tr><td>"+headerName + "</td>");
	   out.println("<td>"+request.getHeader(headerName) + "</td></tr>");
	  }
	  out.println("</table></body></HTML>");
	  
	 }
	
	@Override
	public void destroy() {
	}

}
