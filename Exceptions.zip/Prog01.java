import java.util.Scanner;

public class Prog01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an Integer");
		try {
			int n = Integer.parseInt(sc.next());
			System.out.println("The square value is "+(n*n)+"\nThe work has been done successfully");
		}catch (NumberFormatException e) {
			System.out.println("Entered input is not a valid format for an integer.");
		}
		sc.close();
	}

}
