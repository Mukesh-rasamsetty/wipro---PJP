import java.util.Scanner;

public class Prog05 {

	public void division(int a, int b) throws ArithmeticException
	{
		System.out.println(a/b) ;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			new Prog05().division(sc.nextInt(), sc.nextInt());
		} catch (ArithmeticException e) {
			System.out.println("Arthimetic Exception : divide by Zero...!");
		}
		sc.close();
	}

}
