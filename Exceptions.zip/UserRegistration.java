
public class UserRegistration {
	public void registerUser(String username, String userCountry) throws InvalidCountryException {
		if(userCountry.equalsIgnoreCase("India"))
		{
			System.out.println("User registration done successfully");
		}
		else
			throw new InvalidCountryException();
	}
}
