
public class Prog08 {
	public static void main(String[] args) {
		try {
			String name = args[0];
			int age = Integer.parseInt(args[1]);
			if(age > 17 && age <= 60)
				System.out.println(name +" age is "+age);
			else
				throw new NumberFormatException();
		} catch (NumberFormatException e) {
			System.out.println("java.lang.NumberFormatException...!");
		}
	}
}
