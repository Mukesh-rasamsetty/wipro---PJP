import java.util.Scanner;

public class Prog09 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the 2 numbers");
		int a = sc.nextInt();
		int b = sc.nextInt();
		try {
			System.out.println("The quotient of "+a+"/"+b+" = "+(a/b));
		} catch (ArithmeticException e) {
			System.out.println("DivideByZeroException caught");
		} catch (NumberFormatException e) {
			System.out.println("Java.lang.NumberFormatException..!");
		}
		finally {
			System.out.println("Inside finally block");
		}
		sc.close();
	}

}
