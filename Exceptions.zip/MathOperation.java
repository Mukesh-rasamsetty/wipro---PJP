
public class MathOperation {

	public static void main(String[] args) {
		try {
			int sum = 0;
			for (int i = 0; i < 5; i++) {
				sum = sum + Integer.parseInt(args[i]);
			}
			System.out.println("Sum of the 5 Elements : "+sum);
			System.out.println("Average of the 5 Elements : "+(sum/5));
		} catch (NumberFormatException e) {
			System.out.println("Entered String is not in number format");
		} catch (ArithmeticException e) {
			System.out.println("Arithmetic Exception ");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
