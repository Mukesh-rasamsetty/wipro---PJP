import java.util.Scanner;

public class Prog06 {
	static String name1;
	static String name2;
	static int total;

	public static void input() throws NumberFormatException {
		total = 0;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter student-1 name and 3 subjects marks : ");
		name1 = sc.next();
		for (int i = 0; i < 3; i++) {
			int inp = Integer.parseInt(sc.next());
			if (inp >= 0 && inp <= 100)
				total = total + inp;
			else
				throw new NumberFormatException();
		}
		System.out.println("Enter student-2 name and 3 subjects marks : ");
		name2 = sc.next();
		for (int i = 0; i < 3; i++) {
			int inp = Integer.parseInt(sc.next());
			if (inp >= 0 && inp <= 100)
				total = total + inp;
			else
				throw new NumberFormatException();
		}
		System.out.println("Average of the students marks : "+(total/6));
		sc.close();
	}

	public static void main(String[] args) {
		try {
			input();
		} catch (NumberFormatException e) {
			System.out.println("java.lang.NumberFormatException...!");
		}
	}

}
