import java.util.Scanner;

public class Prog07 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			new UserRegistration().registerUser(sc.next(), sc.next());
		} catch (InvalidCountryException e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}

}
