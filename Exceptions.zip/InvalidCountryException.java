
public class InvalidCountryException extends Exception {

	@Override
	public String getMessage() {
		return ("User Outside India  cannot be registered");
	}

}
