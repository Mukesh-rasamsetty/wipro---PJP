import java.util.HashSet;

public class Set_Prog01 {
	HashSet<String> set;

	public Set_Prog01() {
		set = new HashSet<String>();
	}

	public HashSet<String> saveCountryNames(String CountryName) {
		set.add(CountryName);
		return (HashSet<String>) set;
	}

	public String getCountry(String CountryName) {
		for (String country : set) {
			if (country.equals(CountryName))
				return country;
		}
		return null;
	}

	public static void main(String[] args) {
		Set_Prog01 set_Prog01 = new Set_Prog01();
		HashSet<String> hashSet = set_Prog01.saveCountryNames("India");
		for (String country : hashSet) {
			System.out.println(country);
		}
		System.out.println("************************************************");
		hashSet = set_Prog01.saveCountryNames("USA");
		for (String country : hashSet) {
			System.out.println(country);
		}
		System.out.println("************************************************");
		hashSet = set_Prog01.saveCountryNames("UK");
		for (String country : hashSet) {
			System.out.println(country);
		}
		System.out.println("************************************************");
		hashSet = set_Prog01.saveCountryNames("Canda");
		for (String country : hashSet) {
			System.out.println(country);
		}
		System.out.println("************************************************");
		System.out.println(set_Prog01.getCountry("India"));
		System.out.println("************************************************");
		System.out.println(set_Prog01.getCountry("Pakistan"));
	}
}
