import java.util.Iterator;
import java.util.TreeSet;

public class Set_Prog03 {

	public static void main(String[] args) {
		TreeSet<String> set = new TreeSet<>();
		set.add("Mukesh");
		set.add("Nitish");
		set.add("Aditya");
		set.add("Praveen");
		set.add("Sulthan");
		set.add("Tirumala");
		set.add("Trilok");
		set.add("Charan");
		set = (TreeSet<String>) set.descendingSet();

		Iterator<String> iterator = set.iterator();
		for (String name : set) {
			System.out.println(name);
		}
		System.out.println("**********************************************");

		boolean flag = false;
		for (String name : set) {
			if (name.equals("Mansoor")) {
				flag = true;
				break;
			}
		}
		if (flag)
			System.out.println("Found");
		else
			System.out.println("Not Found");
		System.out.println("**********************************************");

		flag = false;
		for (String name : set) {
			if (name.equals("Mukesh")) {
				flag = true;
				break;
			}
		}
		if (flag)
			System.out.println("Found");
		else
			System.out.println("Not Found");

	}

}
