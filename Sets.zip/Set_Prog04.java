import java.util.TreeSet;

public class Set_Prog04 {
	TreeSet<String> set;

	public Set_Prog04() {
		set = new TreeSet<String>();
	}

	public TreeSet<String> saveCountryNames(String CountryName) {
		set.add(CountryName);
		return (TreeSet<String>) set;
	}

	public String getCountry(String CountryName) {
		for (String country : set) {
			if (country.equals(CountryName))
				return country;
		}
		return null;
	}

	public static void main(String[] args) {
		Set_Prog04 set_Prog04 = new Set_Prog04();
		TreeSet<String> hashSet = set_Prog04.saveCountryNames("India");
		for (String country : hashSet) {
			System.out.println(country);
		}
		System.out.println("************************************************");
		hashSet = set_Prog04.saveCountryNames("USA");
		for (String country : hashSet) {
			System.out.println(country);
		}
		System.out.println("************************************************");
		hashSet = set_Prog04.saveCountryNames("UK");
		for (String country : hashSet) {
			System.out.println(country);
		}
		System.out.println("************************************************");
		hashSet = set_Prog04.saveCountryNames("Canda");
		for (String country : hashSet) {
			System.out.println(country);
		}
		System.out.println("************************************************");
		System.out.println(set_Prog04.getCountry("India"));
		System.out.println("************************************************");
		System.out.println(set_Prog04.getCountry("Pakistan"));
	}

}
