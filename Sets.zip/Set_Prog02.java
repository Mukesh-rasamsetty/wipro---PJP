import java.util.HashSet;

public class Set_Prog02 {
	
	public static void main(String[] args) {
		HashSet<String> set = new HashSet<>();
		set.add("Mukesh");
		set.add("Nitish");
		set.add("Aditya");
		set.add("Praveen");
		set.add("Sulthan");
		set.add("Tirumala");
		set.add("Trilok");
		set.add("Charan");
		for(String name : set) {
			System.out.println(name);
		}
	}

}
