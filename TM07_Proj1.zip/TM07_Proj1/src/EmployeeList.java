import java.util.LinkedList;
import java.util.TreeSet;

public class EmployeeList {
	public LinkedList<Employee> list;

	public EmployeeList() {
		list = new LinkedList<>();
	}

	public void insert(Employee e) {
		list.add(e);
		System.out.println("Inserted Successfully");
	}

	public void sort() {
		LinkedList<Employee> emp = new LinkedList<>();
		TreeSet<String> first = new TreeSet<>();
		for (Employee e : list) {
			first.add(e.getFirstName());
		}
		for (String s : first) {
			for (Employee e : list) {
				if (e.getFirstName().equals(s))
					emp.add(e);
			}
		}
		list = emp;
	}

	public void display() {
		System.out.println("Employee List: \nFirstName\tSecondName\t\tMobileNumber\t\tEmail\t\t\t\tAddres");
		for (Employee emp : list) {
			System.out.println(emp.getFirstName() + "\t\t" + emp.getLastName() + "\t\t" + emp.getMobileNumber() + "\t\t"
					+ emp.getEmail() + "\t\t" + emp.getAddress());
		}
	}
}
