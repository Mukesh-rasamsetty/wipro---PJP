import java.util.Scanner;

public class EmployeeTestMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number of Employees ");
		int n = sc.nextInt();
		EmployeeList employeeList = new EmployeeList();
		for(int i =1 ; i<=n; i++)
		{
			System.out.println("Enter Employee "+i+" Details: ");
			System.out.println("Enter the Firstname");
			String FirstName = sc.next();
			System.out.println("Enter the Lastname");
			String LastName = sc.next();
			System.out.println("Enter the Mobile");
			String Mobile = sc.next();
			System.out.println("Enter the Email");
			String Email = sc.next();
			System.out.println("Enter the Address");
			String Address = sc.next();
			employeeList.insert(new Employee(FirstName, LastName, Mobile, Email,Address));
		}
		employeeList.sort();
		employeeList.display();
		sc.close();
	}

}
