
public class Employee {
	private String FirstName, LastName, MobileNumber, Email,Address;

	public Employee(String firstName, String lastName, String mobileNumber, String email, String Address) {
		FirstName = firstName;
		LastName = lastName;
		MobileNumber = mobileNumber;
		Email = email;
		this.Address =Address;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getFirstName() {
		return FirstName;
	}

	public String getLastName() {
		return LastName;
	}

	public String getMobileNumber() {
		return MobileNumber;
	}

	public String getEmail() {
		return Email;
	}

}
