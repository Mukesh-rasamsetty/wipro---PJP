setTimeout(function(){ alert("3 mins past.....!"); }, 3000*60);

function validate() {
    var letters = /^[A-Za-z]+$/;
    var firstname = document.myform.firstname.value;
    var lastname = document.myform.lastname.value;
    if(!firstname.match(letters)){
        alert('Enter Characters only....!');
        document.getElementById('firstname').focus;
        return;
    }
    if(!lastname.match(letters)){
        alert('Enter Characters only....!');
        document.getElementById('lastname').focus;
        return  ;
    }
    var pwd = document.myform.password.value;
    if(pwd.length >=6 && pwd.length <=20)
    {
        alert('Enter valid Password within range only....!');
        document.getElementById('password').focus;
        return  ;
    }
    var con_pwd = document.myform.conf_password.value;
    if(pwd.length >=6 && pwd.length <=20)
    {
        alert('Enter valid Password within range only....!');
        document.getElementById('conf_password').focus;
        return  ;
    }
    if(con_pwd!=pwd)
    {
        alert('Both password should be same....!');
        return  ;
    }
    if(document.getElementById('Male').checked || document.getElementById('Female').checked)
    {
        alert('Must be selected');
        return  ;
    }
}