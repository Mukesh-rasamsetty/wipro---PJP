import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class Prog06 {

	public static void reverse(List<String> t) {
		 t = t.stream().map(n-> String.valueOf(new StringBuffer(n).reverse())).collect(Collectors.toList());
		 System.out.println(t);
	}
	
	public static void main(String[] args) {
		List<String> words = new ArrayList<>();
		
		words.add("apple");
		words.add("bob");
		words.add("cat");
		words.add("dad");
		words.add("egg");
		words.add("fof");
		words.add("gate");
		words.add("hahahah");
		
		Consumer<List<String>> word = Prog06::reverse;
		word.accept(words);
	}
	
}
