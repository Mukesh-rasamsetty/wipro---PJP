import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Prog04 {

	public static void main(String[] args) {
		List<Employe> emp = new ArrayList<>();

		emp.add(new Employe(501, "Mukesh", 2500));
		emp.add(new Employe(502, "Mansoor", 26000));
		emp.add(new Employe(503, "Lokesh", 2700));
		emp.add(new Employe(504, "Nithish", 28000));
		
		emp = emp.stream().filter(n -> n.getSalary()<10000).collect(Collectors.toList());
		
		emp.forEach(n-> System.out.println(n.getName()));
	}

}
