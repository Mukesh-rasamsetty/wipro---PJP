import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Prog07 {

	public static void list(List<Integer> num) {
		List<String> list = new ArrayList<>();
		for(Integer n : num) {
			if(n%2 == 0)
				list.add(n+" even");
			else
				list.add(n+" odd");
		}
		System.out.println(list);
	}
	
	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<>();
		numbers .add(0);
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
		numbers.add(4);
		numbers.add(5);
		numbers.add(6);
		numbers.add(7);
		numbers.add(8);
		numbers.add(9);
		numbers.add(10);
		Consumer<List<Integer>> number = Prog07::list;
		number.accept(numbers);
	}

}
