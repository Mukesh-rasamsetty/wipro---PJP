import java.util.ArrayList;
import java.util.List;

public class Prog02 implements Functional_Interface_1{

	public static void main(String[] args) {
		List<Integer> elements = new ArrayList<>();
		
		elements.add(10);
		elements.add(20);
		elements.add(30);
		elements.add(40);
		elements.add(50);
		elements.add(60);
		elements.add(70);
		elements.add(80);
		elements.add(90);
		elements.add(100);
		
		new Prog02().operation(elements);
	}

	@Override
	public <T> void operation(List<T> t) {
		int sum = 0;
		for(T t1: t) {
			sum = sum + (Integer)t1;
		}
		System.out.println(sum);
	}
	
	

}
