import java.util.ArrayList;
import java.util.List;

public class Prog01 implements Functional_Interface_1 {

	public static void main(String[] args) {
		List<Employee> emp = new ArrayList<>();
		
		emp.add(new Employee(501, "Mukesh", "KVL", 25000));
		emp.add(new Employee(502, "Mansoor", "BUJI", 26000));
		emp.add(new Employee(503, "Lokesh", "ONG", 27000));
		emp.add(new Employee(504, "Nithish", "KVL", 28000));
	
		new Prog01().operation(emp);
	}
		
	@Override
	public <T> void operation(List<T> t) {
		List<String> location = new ArrayList<>();
		for(T emp : t) {
			location.add(((Employee) emp).getLocation());
		}
		System.out.println(location);
	} 

}
