import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class Prog08 {

	public static List<Integer> first10PrimeNumbers(){
		List<Integer> numbers = new ArrayList<>();
		int i=0;
		int k=2;
		while(i!=10)
		{
			boolean flag = true;
			for(int j = 2; j< k ;j++)
			{
				if(k % j == 0)
					flag = false;
			}
			if(flag)
			{
				numbers.add(k);
				i++;
			}
			k++;
		}
		return numbers;
	}
	
	public static void main(String[] args) {
		Supplier<List<Integer>> supplier = Prog08::first10PrimeNumbers;
		System.out.println(supplier.get());
	}

}
