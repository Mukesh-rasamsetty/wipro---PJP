import java.util.List;

public interface Functional_Interface_1 {
	public <T> void operation(List<T> t);
}
