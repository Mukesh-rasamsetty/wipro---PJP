import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Prog03 {

	public static void main(String[] args) {
		List<String> words = new ArrayList<>();
		
		words.add("apple");
		words.add("bob");
		words.add("cat");
		words.add("dad");
		words.add("egg");
		words.add("fof");
		words.add("gate");
		words.add("hahahah");
		
		words = words.stream().filter(n-> n.equals(String.valueOf(new StringBuffer(n).reverse()))).collect(Collectors.toList());
		System.out.println(words);
	}

}
