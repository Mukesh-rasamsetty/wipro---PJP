import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class Prog01 {

	public static void main(String[] args) {
		List<String> words = new ArrayList<>();

		words.add("apple");
		words.add("bob");
		words.add("cat");
		words.add("dad");
		words.add("egg");
		words.add("fof");
		words.add("gate");
		words.add("hahahah");
		
		StringJoiner joiner = new StringJoiner(" , ","{ "," }");
		words.forEach(n-> joiner.add(n));
		
		System.out.println(joiner);
	}

}
