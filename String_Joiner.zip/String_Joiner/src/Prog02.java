import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class Prog02 {

	public static void main(String[] args) {
		List<String> cities = new ArrayList<>();
		cities.add("Kavali");
		cities.add("Ongole");
		cities.add("HYD");
		cities.add("BEG");
		cities.add("Tirupati");
		cities.add("Chennai");
		cities.add("Nellore");
		cities.add("Indore");
		cities.add("Mumbai");
		cities.add("Jaipur");
		cities.add("Araku");
		
		StringJoiner s1 = new StringJoiner(" - ");
		for(int i =0; i< 5; i++)
		{
			s1.add(cities.get(i));
		}
		
		StringJoiner s2 = new StringJoiner(" - ");
		for(int i =5; i< cities.size(); i++)
		{
			s2.add(cities.get(i));
		}
		
		System.out.println(s1.merge(s2));
		
		System.out.println(s2.merge(s1));
	}

}
