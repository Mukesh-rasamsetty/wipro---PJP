import java.util.Arrays;
import java.util.Scanner;

public class Prog02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		char[] ch = str.toCharArray();
		Arrays.parallelSort(ch);
		System.out.println(String.valueOf(ch));
		sc.close();
	}

}
