import java.util.Arrays;

public class Prog03 {

	public static void main(String[] args) {
		int[] arr= {3,7,2,5,1,55,14,65,35,75};
		Arrays.parallelSort(arr,0,5);
		System.out.println("Array elements {3,7,2,5,1,55,14,65,35,75} after sorting first 5 elements is as follows :");
		for(int i : arr)
			System.out.print(i+"\t");
	}

}
