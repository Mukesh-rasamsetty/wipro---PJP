import java.util.Arrays;

public class Prog01 {

	public static void main(String[] args) {
		int[] arr= {3,7,2,5,1,55,65,14,35,75,59};
		Arrays.parallelSort(arr);
		System.out.println("Array elements {3,7,2,5,1,55,65,14,35,75,59} after sorting is as follows :");
		for(int i : arr)
			System.out.print(i+"\t");
		System.out.println();
		System.out.println("---> Sum of Max and Min elements are : "+(arr[0]+arr[10]));
	}

}
