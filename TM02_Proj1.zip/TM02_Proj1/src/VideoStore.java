import java.util.LinkedList;

public class VideoStore {
	private LinkedList<Video> store;
	int i = 0 ;

	public VideoStore() {
		store = new LinkedList<>();
	}

	public void addVideo(String name) {
		store.add(new Video(name));
		System.out.println("Video \""+name+"\" added successfully.");
	}

	public void doCheckout(String name) {
		for (Video videoname : store) {
			System.out.println(videoname.getName());
			if (videoname.getName().equals(name)) {
				videoname.doCheckout();
				System.out.println("Video \""+name+"\" checked out successfully.");
				break;
			}
		}
	}

	public void doReturn(String name) {
		for (Video videoname : store) {
			if (videoname.getName().equals(name)) {
				videoname.doReturn();
				System.out.println("Video \""+name+"\" returned successfully.");
				
				break;
			}
		}
	}

	public void receiveRating(String name, int rating) {
		for (Video videoname : store) {
			if (videoname.getName().equals(name)) {
				videoname.receiveRating(rating);
				System.out.println("Rating \""+rating+"\" has been mapped to the Video \""+name+"\".");
				break;
			}
		}
	}

	public void listInventory() {
		System.out.println("---------------------------------------------------------------------");
		System.out.println("Video Name\t|\tCheckout Status\t|\tRating");
		for (Video videoname : store) {
			System.out.println(videoname.getName() + "\t\t|\t" + videoname.getCheckout() + "\t\t|\t" + videoname.getRating());
		}
		System.out.println("---------------------------------------------------------------------");
	}
}
