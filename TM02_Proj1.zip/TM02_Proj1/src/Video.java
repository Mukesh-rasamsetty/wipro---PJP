
public class Video {
	private String videoname;
	private boolean checkout;
	private int rating;
	
	public Video(String videoname)
	{
		this.videoname = videoname;
		this.checkout = false;
		this.rating = 0;
	}

	public String getName() {
		return videoname;
	}
	
	public void doCheckout() {
		checkout = true;
	}
	
	public void doReturn() {
		checkout = false;
	}
	
	public void receiveRating(int rating) {
		this.rating = rating;
	}
	
	public int getRating()
	{
		return this.rating;
	}
	
	public boolean getCheckout()
	{
		return this.checkout;
	}
}
