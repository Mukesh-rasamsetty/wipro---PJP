
public class Employee {
	private int id;
	private String name, address, salary;

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getSalary() {
		return salary;
	}

	public Employee(int id, String name, String address, String salary) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}

}