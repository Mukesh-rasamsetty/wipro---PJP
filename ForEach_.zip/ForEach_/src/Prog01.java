import java.util.ArrayList;
import java.util.List;

public class Prog01 {

	public static void main(String[] args) {
		List<String> weekdays = new ArrayList<>();
		weekdays.add("Sunday");
		weekdays.add("Monday");
		weekdays.add("Tuesday");
		weekdays.add("Wendesday");
		weekdays.add("Thursday");
		weekdays.add("Friday");
		weekdays.add("Saturday");
		
		weekdays.forEach(n -> System.out.println(n));
	}

}
