import java.util.ArrayList;
import java.util.List;

public class Prog02 {

	public static void main(String[] args) {
		List<Employee> al = new ArrayList<>();
		al.add(new Employee(533, "Mukesh", "KVL", "30000"));
		al.add(new Employee(534, "Mansoor", "NRL", "35000"));
		al.add(new Employee(535, "Nitish", "KVL", "35000"));
		al.add(new Employee(532, "Lokesh", "ONG", "32000"));
		al.add(new Employee(530, "Aditya", "KVL", "30000"));

		al.forEach(
				n -> System.out.println("ID :" + n.getId() + "\nName : " + n.getName() + "\nAddress : " + n.getAddress()
						+ "\nSalary : " + n.getSalary() + "\n-------------------------------------------------"));

	}

}
