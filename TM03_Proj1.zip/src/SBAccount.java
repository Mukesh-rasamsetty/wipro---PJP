
public class SBAccount extends Account {
	String type;

	public SBAccount(double amount, String type) {
		super(amount);
		this.type = type;
	}
	
	public double getInterest() {
		if(type.equals("Normal"))
			return 4;
		else if(type.equals("NRI"))
			return 6;
		else 
			throw new NumberFormatException();
	}
	
	@Override
	public double calculateInterest() {
		return (getInterest()*amount)/100;
	}

}
