import java.util.Scanner;

public class TestAccount {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		abc :while(true) {
			System.out.print("MAIN MENU\n --------- \n1. Interest Calculator � SB  \n2. Interest Calculator � FD  \n3. Interest Calculator � RD  \n4. Exit  \nEnter your option (1..4): ");
			int n = sc.nextInt();
			switch(n) {
			case 1:
				try {
				System.out.print("Enter type of Account ");
				String type = sc.next();
				System.out.print("Enter the Average amount in your account: ");
				System.out.println("Interest gained:  Rs. "+new SBAccount(sc.nextInt(), type).calculateInterest());
				} catch(NumberFormatException e)
				{
					System.out.println("Enter correct Account type.");
				}
				break;
			case 2:
				try {
					System.out.print("Enter the FD amount: ");
					int amount = sc.nextInt();
					System.out.print("Enter the number of days: ");
					int days = sc.nextInt();
					System.out.print("Enter your age : ");
					int age = sc.nextInt();
					System.out.println("Interest gained is:  Rs. "+new FDAccount(amount, days, age).calculateInterest() );
				} catch (NumberFormatException e) {
					System.out.println("Invalid Number of Days.");
				} catch (NoSuchFieldError e) {
					System.out.println("Invalid Number of days. Please enter non-negative values.    ");
				} catch (ArithmeticException e) {
					System.out.println("Invalid age. Please enter non-negative values.    ");
				}
				break;
			case 3:
				try {
					System.out.print("Enter the RD amount: ");
					int amount = sc.nextInt();
					System.out.print("Enter the number of Months: ");
					int days = sc.nextInt();
					System.out.print("Enter your age : ");
					int age = sc.nextInt();
					System.out.println("Interest gained is:  Rs. "+new RDAccount(amount, days, age).calculateInterest() );
				} catch (NumberFormatException e) {
					System.out.println("Invalid Number of Days.");
				} catch (NoSuchFieldError e) {
					System.out.println("Invalid Number of days. Please enter non-negative values.    ");
				} catch (ArithmeticException e) {
					System.out.println("Invalid age. Please enter non-negative values.    ");
				}
				break;
			case 4:
				break abc;
			default :
				System.out.println("Invalid entry...!");
			}
		}
		sc.close();
	}

}
