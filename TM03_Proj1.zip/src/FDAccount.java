
public class FDAccount extends Account {
	public int no_of_Days;
	public int age;

	public FDAccount(double amount, int no_of_Days, int age) {
		super(amount);
		this.no_of_Days = no_of_Days;
		this.age = age;
	}

	public double getInterset() throws NumberFormatException {
		if (amount >= 10000000) {
			if (no_of_Days >= 7 && no_of_Days <= 14)
				return 6.50;
			else if (no_of_Days >= 15 && no_of_Days <= 29)
				return 6.75;
			else if (no_of_Days >= 30 && no_of_Days <= 45)
				return 6.75;
			else if (no_of_Days >= 45 && no_of_Days <= 60)
				return 8.0;
			else if (no_of_Days >= 61 && no_of_Days <= 184)
				return 8.50;
			else if (no_of_Days >= 185 && no_of_Days <= 365)
				return 10.0;
			else
				throw new NumberFormatException();
		} else {
			if (age < 50 && age > 0) {
				if (no_of_Days >= 7 && no_of_Days <= 14)
					return 4.50;
				else if (no_of_Days >= 15 && no_of_Days <= 29)
					return 4.75;
				else if (no_of_Days >= 30 && no_of_Days <= 45)
					return 5.50;
				else if (no_of_Days >= 45 && no_of_Days <= 60)
					return 7.0;
				else if (no_of_Days >= 61 && no_of_Days <= 184)
					return 7.50;
				else if (no_of_Days >= 185 && no_of_Days <= 365)
					return 8.0;
				else
					throw new NumberFormatException();
			} else if (age >= 50) {
				if (no_of_Days >= 7 && no_of_Days <= 14)
					return 5.0;
				else if (no_of_Days >= 15 && no_of_Days <= 29)
					return 5.25;
				else if (no_of_Days >= 30 && no_of_Days <= 45)
					return 6.00;
				else if (no_of_Days >= 45 && no_of_Days <= 60)
					return 7.5;
				else if (no_of_Days >= 61 && no_of_Days <= 184)
					return 8.00;
				else if (no_of_Days >= 185 && no_of_Days <= 365)
					return 8.50;
				else
					throw new NumberFormatException();
			} else
				throw new ArithmeticException();
		}
	}

	@Override
	public double calculateInterest() {
		return (getInterset() * amount) / 100;
	}

}
