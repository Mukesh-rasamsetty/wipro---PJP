
public class RDAccount extends Account {
	public int no_of_Months;
	public int age;

	public RDAccount(double amount, int no_of, int age) {
		super(amount);
		this.no_of_Months = no_of;
		this.age = age;
	}

	public double getInterset() throws NumberFormatException {
		if (age < 50 && age > 0) {
			if (no_of_Months >= 1 && no_of_Months <= 6)
				return 7.50;
			else if (no_of_Months >= 7 && no_of_Months <= 9)
				return 7.75;
			else if (no_of_Months >= 10 && no_of_Months <= 12)
				return 8.00;
			else if (no_of_Months >= 13 && no_of_Months <= 15)
				return 8.25;
			else if (no_of_Months >= 16 && no_of_Months <= 18)
				return 8.50;
			else if (no_of_Months >= 19 && no_of_Months <= 21)
				return 8.75;
			else
				throw new NumberFormatException();
		} else if (age >= 50) {
			if (no_of_Months >= 1 && no_of_Months <= 6)
				return 8.00;
			else if (no_of_Months >= 7 && no_of_Months <= 9)
				return 8.25;
			else if (no_of_Months >= 10 && no_of_Months <= 12)
				return 8.50;
			else if (no_of_Months >= 13 && no_of_Months <= 15)
				return 8.75;
			else if (no_of_Months >= 16 && no_of_Months <= 18)
				return 9.00;
			else if (no_of_Months >= 19 && no_of_Months <= 21)
				return 9.25;
			else
				throw new NumberFormatException();
		} else
			throw new ArithmeticException();
	}

	@Override
	public double calculateInterest() {
		return (getInterset() * amount) / 100;
	}

}
