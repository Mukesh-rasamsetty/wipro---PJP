import java.util.Scanner;

public class MainCard {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Cards :");
		int n = sc.nextInt();
		CardList cardList = new CardList();
		for(int i=1; i<=n; i++) {
			System.out.println("Enter Card "+i+":");
			char ch = sc.next().charAt(0);
			int Number = sc.nextInt();
			cardList.add(new Card(ch, Number));
		}
		cardList.display();
		sc.close();
	}
}
