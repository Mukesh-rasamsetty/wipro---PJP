import java.util.LinkedList;
import java.util.TreeSet;

public class CardList {
	LinkedList<Card> cards;
	
	public CardList() {
		cards = new LinkedList<>();
	}
	
	public void add(Card c)
	{
		cards.add(c);
	}
	
	public void display()
	{
		TreeSet<Character> tree = new TreeSet<>();
		for(Card c : cards) {
			tree.add(c.getAlphabet());
		}
		System.out.println("Distinct Symbols are :");
		for(Character c : tree) {
			System.out.print(c.charValue()+" ");
		}
		System.out.println();
		for(Character c : tree) {
			int sum=0,count =0;
			System.out.println("Cards in "+c.charValue()+" Symbol ");
			for(Card card : cards) {
				if(card.getAlphabet() == c.charValue()) {
					System.out.println(card.getAlphabet()+" "+card.getNumber());
					count++;
					sum = sum + card.getNumber();
				}
			}
			System.out.println("Number of cards : "+count+"\nSum of Numbers : "+sum);
		}
	}
}
