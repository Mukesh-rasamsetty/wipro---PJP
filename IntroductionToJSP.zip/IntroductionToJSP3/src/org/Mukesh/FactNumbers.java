package org.Mukesh;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FactNumbers")
public class FactNumbers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int range = Integer.parseInt(request.getParameter("number"));
		List<Factorial> list = new ArrayList<>();
		for(int i=1; i<=range; i++) {
			int k = 1;
			int res = 1;
			while(k <= i) {
				res = res * k;
				k++;
			}
			list.add(new Factorial(i, res));
		}
		request.setAttribute("list", list);
		request.getRequestDispatcher("View.jsp").forward(request, response);
	}

}
