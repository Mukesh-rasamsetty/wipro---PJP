package org.Mukesh;

public class Factorial {
	private int value,result;

	public Factorial(int value, int result) {
		this.value = value;
		this.result = result;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}
	
}
