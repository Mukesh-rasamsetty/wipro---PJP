package org.Mukesh;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PrimeNumbers")
public class PrimeNumbers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int range = Integer.parseInt(request.getParameter("number"));
		List<Integer> list = new ArrayList<>();
		for(int i = 2; i <= range; i++) {
			boolean flag = true;
			for(int j = 2; j < i ; j++) {
				if(i % j == 0)
				{
					flag = false;
					break;
				}
			}
			if(flag)
				list.add(i);
		}
		request.setAttribute("list", list);
		request.getRequestDispatcher("View.jsp").forward(request, response);
	}

}
