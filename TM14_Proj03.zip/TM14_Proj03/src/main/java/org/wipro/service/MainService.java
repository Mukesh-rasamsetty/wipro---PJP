package org.wipro.service;

import java.util.List;

import org.wipro.DAO.CouponDAO;
import org.wipro.DAO.CustomerDAO;
import org.wipro.model.Coupon;
import org.wipro.model.Customer;

public class MainService {
	
	CustomerDAO custDAO = new CustomerDAO();
	CouponDAO couDAO = new CouponDAO();
	
	public MainService() {
		
	}
	
	public Customer getCustomer(String id, String password) {
		List<Customer> list = custDAO.getList();
		for(Customer temp : list) {
			if(temp.getCustomerID().equals(id))
			{
				if(temp.getPassword().equals(password))
					return temp;
			}
		}
		return null;
	}

	public Coupon getCoupon(String id) {
		Coupon coupon = couDAO.getCouponDetails(id);
		return coupon;
	}

	public void updateCustomer(Customer customer) {
		custDAO.update(customer);
	}

}
