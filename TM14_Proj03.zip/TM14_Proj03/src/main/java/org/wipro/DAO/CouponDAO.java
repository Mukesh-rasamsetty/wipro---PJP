package org.wipro.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.wipro.model.Coupon;

public class CouponDAO {
	
	SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Coupon.class)
			.buildSessionFactory();
	
	public Coupon getCouponDetails(String coupon)
	{
		try {
			Session session = sessionFactory.getCurrentSession();
			session.beginTransaction();
			Coupon cou = session.get(Coupon.class, coupon);
			session.close();
			return cou;
		}catch (Exception e) {
			return null;
		}
	}
}
