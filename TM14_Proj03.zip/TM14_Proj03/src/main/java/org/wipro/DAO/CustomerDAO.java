package org.wipro.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.wipro.model.Customer;


public class CustomerDAO {

	SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Customer.class)
			.buildSessionFactory();

	@SuppressWarnings("unchecked")
	public List<Customer> getList() {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		List<Customer> list = session.createQuery("from customer").getResultList();
		session.close();
		return list;
	}

	public void update(Customer customer) {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		session.update(customer);
		session.getTransaction().commit();
		session.close();
	}

}
