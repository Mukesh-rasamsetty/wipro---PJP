package org.wipro.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "coupon")
@Table(name = "coupon")
public class Coupon {
	
	@Id
	@Column
	String CouponCode;
	
	@Column
	int OfferPercentage;

	public Coupon() {
		
	}

	public Coupon(String couponCode, int offerPercentage) {
		CouponCode = couponCode;
		OfferPercentage = offerPercentage;
	}

	public String getCouponCode() {
		return CouponCode;
	}

	public void setCouponCode(String couponCode) {
		CouponCode = couponCode;
	}

	public int getOfferPercentage() {
		return OfferPercentage;
	}

	public void setOfferPercentage(int offerPercentage) {
		OfferPercentage = offerPercentage;
	}

	@Override
	public String toString() {
		return "Coupon [CouponCode=" + CouponCode + ", OfferPercentage=" + OfferPercentage + "]";
	}
	
}
