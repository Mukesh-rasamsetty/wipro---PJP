package org.wipro.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "customer")
@Table(name = "customer")
public class Customer {
	
	@Id
	@Column
	String CustomerID;
	@Column
	String Password;
	@Column
	int Balance;
	
	public Customer() {
		
	}

	public Customer(String customer, String password, int balance) {
		CustomerID = customer;
		Password = password;
		Balance = balance;
	}

	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customer) {
		CustomerID = customer;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public int getBalance() {
		return Balance;
	}

	public void setBalance(int balance) {
		Balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [Customer=" + CustomerID + ", Password=" + Password + ", Balance=" + Balance + "]";
	}
	
}
