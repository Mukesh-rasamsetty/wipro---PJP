package org.wipro.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.wipro.model.Coupon;
import org.wipro.model.Customer;
import org.wipro.service.MainService;

@Controller
public class MainController {
	
	MainService service = new MainService();
	
	@PostMapping("Login")
	public ModelAndView login(@RequestParam("id") String id, @RequestParam("password") String password)
	{
		Customer customer = service.getCustomer(id,password);
		if(customer == null) {
			ModelAndView mv = new ModelAndView("error");
			mv.addObject("Message", "Incorrect UserName/Password...!");
			return mv;
		}
		ModelAndView mv1 = new ModelAndView("couponEntry");
		mv1.addObject("customer", customer);
		return mv1;
	}
	
	@PostMapping("CouponEntry")
	public ModelAndView couponEntry(@RequestParam("id") String id, @RequestParam("bal") String bal,@RequestParam("pwd") String pwd,@RequestParam("custId") String custId) {
		Coupon coupon = service.getCoupon(id);
		if(coupon == null) {
			ModelAndView mv = new ModelAndView("error");
			mv.addObject("Message", "Incorrect Coupon Number...!");
			return mv;
		}
		int balance = Integer.parseInt(bal);
		int per = coupon.getOfferPercentage();
		balance +=(int)(balance*per/100);
		Customer customer = new Customer(custId, pwd, balance);
		service.updateCustomer(customer);
		ModelAndView mv1 = new ModelAndView("final");
		mv1.addObject("percentage", per);
		mv1.addObject("balance", balance);
		return mv1;
	}
}
