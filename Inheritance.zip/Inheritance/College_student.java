
public class College_student extends Student{
	String clgname,year;

	public College_student(String name, String dob, int studentid, String clgname, String year) {
		super(name, dob, studentid);
		this.clgname = clgname;
		this.year = year;
	}

	public String getClgname() {
		return clgname;
	}

	public String getYear() {
		return year;
	}
	
}
