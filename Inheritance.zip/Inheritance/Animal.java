
public class Animal {
	public void eat() {
		System.out.println("Animal is Eating..!");
	}

	public void sleep() {
		System.out.println("Animal is Sleeping...!");
	}
}
