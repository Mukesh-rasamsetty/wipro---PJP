
public class Inheritance_prog03 {

	public static void main(String[] args) {
		College_student college_student = new College_student("Mukesh", "10AUG1999", 533, "PBR VITS", "Fourth");
		System.out.println("....................Student details....................");
		System.out.println("Name : "+college_student.getName());
		System.out.println("Collge Name : "+college_student.getClgname());
		System.out.println("Date of Birth : "+college_student.getDOB());
		System.out.println("ID : "+college_student.getStudentid());
		System.out.println("Current year : "+college_student.getYear());
	}

}
