
public class Person {
	private String name, DOB;

	public Person(String name, String dob) {
		this.name = name;
		this.DOB = dob;
	}

	public Person(String name) {
		this.name = name;
	};

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

}
