
public class TestEmployee {

	public static void main(String[] args) {
		Employee employee = new Employee("Mukesh", 360000, "May2020", "16731A0533");
		System.out.println("...........................Employee Details.......................");
		System.out.println("Name : "+employee.getName());
		System.out.println("Annual Salary : "+employee.getAnnual_salary());
		System.out.println("Work Starting Date : "+employee.getWork_starting_Date());
		System.out.println("National Insurance Number : "+employee.getNational_Insurance_number());
	}

}
