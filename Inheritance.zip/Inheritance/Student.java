
public class Student extends Person{
	int Studentid;

	public Student(String name, String dob, int studentid) {
		super(name, dob);
		Studentid = studentid;
	}

	public int getStudentid() {
		return Studentid;
	}
	
	
}
