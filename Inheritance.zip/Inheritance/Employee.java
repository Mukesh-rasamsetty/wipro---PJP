
public class Employee extends Person {

	private double annual_salary;
	private String work_starting_Date, National_Insurance_number;

	public Employee(String name, double annual_salary, String work_starting_Date, String national_Insurance_number) {
		super(name);
		this.annual_salary = annual_salary;
		this.work_starting_Date = work_starting_Date;
		National_Insurance_number = national_Insurance_number;
	}

	public double getAnnual_salary() {
		return annual_salary;
	}

	public void setAnnual_salary(double annual_salary) {
		this.annual_salary = annual_salary;
	}

	public String getWork_starting_Date() {
		return work_starting_Date;
	}

	public void setWork_starting_Date(String work_starting_Date) {
		this.work_starting_Date = work_starting_Date;
	}

	public String getNational_Insurance_number() {
		return National_Insurance_number;
	}

	public void setNational_Insurance_number(String national_Insurance_number) {
		National_Insurance_number = national_Insurance_number;
	}

}
