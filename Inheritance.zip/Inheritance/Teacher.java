
public class Teacher extends Person {
	private double salary;
	private String subject;

	public Teacher(String name, String dob, double salary, String subject) {
		super(name, dob);
		this.salary = salary;
		this.subject = subject;
	}

	public double getSalary() {
		return salary;
	}

	public String getSubject() {
		return subject;
	}

}
