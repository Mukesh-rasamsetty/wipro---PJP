import java.util.Optional;

public class Prog03 {

	public static void main(String[] args) {
		Employeee emp = null;
		Optional<Employeee> opt = Optional.ofNullable(emp);
		System.out.println(opt.orElseThrow(UserException::new));
	}

}
