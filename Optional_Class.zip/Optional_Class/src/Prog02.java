import java.util.Optional;

public class Prog02 {
	public static void main(String[] args) {
		String address = null ;
		Optional<String> optional = Optional.ofNullable(address);
		System.out.println(optional.orElse("INDIA"));
	}
}
