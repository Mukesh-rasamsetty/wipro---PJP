
public class UserException extends NullPointerException {

	private static final long serialVersionUID = 1L;
	
	public UserException() {
	}

	public UserException(String s) {
	}

	@Override
	public void printStackTrace() {
		System.out.println("Not an Valid Employee Details");
	}

	@Override
	public String toString() {
		return "Not an Employee";
	}
	
}
