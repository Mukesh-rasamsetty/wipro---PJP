import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Demo1Test {

	@Test
	void testStringConcat() {
		Demo1 demo = new Demo1();
		assertEquals("Hello World", demo.stringConcat("Hello ", "World"));
	}

}
