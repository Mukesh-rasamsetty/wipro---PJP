import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Demo2Test {

	@Test
	void testPalindromeCheck() {
		assertTrue(new Demo2().palindromeCheck("abcba"),"Alert1");
		assertFalse(new Demo2().palindromeCheck("Panapa"),"Alert2");
	}

}
