
public class Demo2 {
	
	public boolean palindromeCheck(String str) {
		StringBuilder str2 = new StringBuilder(str);
		String str1 = String.valueOf(str2.reverse());
		if(str1.equals(str))
			return true;
		else
			return false; 
	}
}
