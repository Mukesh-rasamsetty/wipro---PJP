import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class EmployeeTest {

	@Test
	void testFindName() {
		ArrayList<String> empnames = new ArrayList<>();
		empnames.add("Mukesh");
		empnames.add("Manohar");
		empnames.add("Aditya");
		empnames.add("Mansoor");
		empnames.add("Mahesh");
		assertEquals("FOUND", new Employee().findName(empnames, "Mukesh"));
		assertEquals("NOT FOUND", new Employee().findName(empnames, "Rakesh"));
	}

}
