
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Handler")
public class Handler extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("id",request.getParameter("id"));
		request.setAttribute("item_name", request.getParameter("item_name"));
		request.setAttribute("name",request.getParameter("name"));
		request.setAttribute("email",request.getParameter("email"));
		request.setAttribute("amount",request.getParameter("amount"));
		if(request.getParameter("check").equals(null))
			request.setAttribute("bid", request.getParameter("false"));
		else
			request.setAttribute("bid", request.getParameter("true"));
		request.getRequestDispatcher("View.jsp").forward(request, response);
	}

}
