class Patient
{
	String patientname;
	double height, weight;

	Patient(String name, int height, int weight)
	{
		this.patientname = name;
		this.height = height;
		this.width  = width;
	}

	public double computeBMI()
	{
		return weight/(height*height);
	}
}
