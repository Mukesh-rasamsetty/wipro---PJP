class Calculator 
{
	public static double PowerInt(int a, int b)
	{
		return Math.pow(a,b);
	}
	
	public static double PowerDouble(double a , int b)
	{
		return Math.pow(a,b);
	}

	public static void main(String[] args) 
	{
		System.out.println(Calculator.PowerInt(2,10));
		System.out.println(Calculator.PowerDouble(2.2,10));
	}
}
