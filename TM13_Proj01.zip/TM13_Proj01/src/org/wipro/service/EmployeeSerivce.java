package org.wipro.service;

import java.util.List;
import org.wipro.DAO.EmployeeDAO;
import org.wipro.model.Employee;

public class EmployeeSerivce {

	private EmployeeDAO dao = new EmployeeDAO();
	
	public List<Employee> getList() {
		return dao.getList();
	}

	public Employee getListById(int id) {
		return dao.getListById(id);
	}

	public void addEmployee(Employee e) {
		dao.addEmployee(e);
	}

	public void deleteEmployee(String parameter) {
		dao.deleteEmployee(Integer.parseInt(parameter));
	}

	public void updateEmployee(String id, Employee e1) {
		dao.updateEmployee(Integer.parseInt(id), e1);
	}
}