package org.wipro.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.wipro.model.Employee;
import org.wipro.service.EmployeeSerivce;

@WebServlet("/user")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private EmployeeSerivce service = new EmployeeSerivce();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String page = request.getParameter("page");
		switch(page) {
		case "ListUsers" : 
			request.setAttribute("list", service.getList());
			request.getRequestDispatcher("list.jsp").forward(request, response);
			break;
		
		case "Search":
			request.getRequestDispatcher("search.jsp").forward(request, response);
			break;
			
		case "Add":
			request.getRequestDispatcher("add.jsp").forward(request, response);
			break;
			
		case "home":
			request.getRequestDispatcher("index.jsp").forward(request, response);
			break;
		
		case "Update":
			int id = Integer.parseInt(request.getParameter("id"));
			Employee emp = service.getListById(id);
			request.setAttribute("emp", emp);
			request.getRequestDispatcher("update.jsp").forward(request, response);
			break;
		
		case "deleteform":
			service.deleteEmployee(request.getParameter("id"));
			request.setAttribute("list", service.getList());
			request.getRequestDispatcher("list.jsp").forward(request, response);
			break;
			
		default : 
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String page = request.getParameter("page");
		switch(page) {
		
		case "search":
			int id = Integer.parseInt(request.getParameter("id"));
			Employee emp = service.getListById(id);
			if(emp != null)
			{
				request.setAttribute("empById", emp);
				request.getRequestDispatcher("listById.jsp").forward(request, response);
			} else 
				request.getRequestDispatcher("error.jsp").forward(request, response);
			break;
			
		case "add":
			Employee e = new Employee();
			e.setName(request.getParameter("name"));
			e.setGender(request.getParameter("gender"));
			e.setDesignation(request.getParameter("designation"));
			e.setSalary(request.getParameter("salary"));
			e.setCity(request.getParameter("city"));
			e.setEmail(request.getParameter("email"));
			e.setContact(request.getParameter("contact"));
			service.addEmployee(e);
			request.setAttribute("list", service.getList());
			request.getRequestDispatcher("list.jsp").forward(request, response);
			break;
			
		case "update":
			Employee e1 = new Employee();
			e1.setId(Integer.parseInt(request.getParameter("id")));
			e1.setName(request.getParameter("name"));
			e1.setGender(request.getParameter("gender"));
			e1.setDesignation(request.getParameter("designation"));
			e1.setSalary(request.getParameter("salary"));
			e1.setCity(request.getParameter("city"));
			e1.setEmail(request.getParameter("email"));
			e1.setContact(request.getParameter("contact"));
			service.updateEmployee(request.getParameter("id"),e1);
			request.setAttribute("list", service.getList());
			request.getRequestDispatcher("list.jsp").forward(request, response);
			break;
			
		case "home":
			request.getRequestDispatcher("index.jsp").forward(request, response);
			break;
			
		default : 
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

}
