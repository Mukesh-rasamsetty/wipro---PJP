package org.wipro.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name = "employee")
@Table(name = "employee")
public class Employee {

	
	@javax.persistence.Id
	@Column(name = "Id")
	private int Id;
	@Column(name = "Name")
	private String Name;
	@Column(name = "Gender")
	private String Gender;
	@Column(name = "Designation")
	private String Designation;
	@Column(name = "Salary")
	private String Salary;
	@Column(name = "City")
	private String City;
	@Column(name = "Email")
	private String Email;
	@Column(name = "Contact")
	private String Contact;

	public Employee() {

	}

	public Employee(String name, String gender, String designation, String salary, String city, String email,
			String contact) {
		Name = name;
		Gender = gender;
		Designation = designation;
		Salary = salary;
		City = city;
		Email = email;
		Contact = contact;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getSalary() {
		return Salary;
	}

	public void setSalary(String salary) {
		Salary = salary;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getContact() {
		return Contact;
	}

	public void setContact(String contact) {
		Contact = contact;
	}

}
