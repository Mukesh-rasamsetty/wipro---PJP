package org.wipro.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.wipro.model.Employee;

public class EmployeeDAO {

	SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class).buildSessionFactory();
	
	public List<Employee> getList() {
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		List<Employee> list = session.createQuery("from employee").getResultList();
		session.getTransaction().commit();
		session.close();
		return list;
	}

	public Employee getListById(int id) {
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		List<Employee> emp = session.createQuery("from employee where Id = "+id).getResultList();
		if(emp.size() > 0)
			return emp.get(0);
		return null;
	}

	public void addEmployee(Employee e) {
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		session.save(e);
		session.getTransaction().commit();
		session.close();
	}

	public void deleteEmployee(int id) {
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		session.delete(session.get(Employee.class, id));
		session.getTransaction().commit();
		session.close();
	}
	
	public void updateEmployee(int id, Employee e) {
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		session.update(e);
		session.getTransaction().commit();
		session.close();
	}
}
