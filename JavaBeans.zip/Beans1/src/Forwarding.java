
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Forwarding")
public class Forwarding extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int n = Integer.parseInt(request.getParameter("num"));
		if(n <= 10)
			request.getRequestDispatcher("Page1.jsp").forward(request, response);
		else if(n <= 99)
			request.getRequestDispatcher("Page2.jsp").forward(request, response);
		else 
			request.getRequestDispatcher("Error.jsp").forward(request, response);
	}

}
