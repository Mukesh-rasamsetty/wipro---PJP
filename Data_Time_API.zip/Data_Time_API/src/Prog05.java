import java.time.LocalTime;

public class Prog05 {

	public static void main(String[] args) {
		LocalTime time = LocalTime.now();
		System.out.println(time);
		System.out.println(time.plusMinutes(25));
	}

}
