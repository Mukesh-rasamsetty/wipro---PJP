import java.time.LocalDate;

public class Prog04 {

	public static void main(String[] args) {
		LocalDate date = LocalDate.now();
		System.out.println(date.isLeapYear()?"Leapyear":"Not a LeapYear");
	}

}
