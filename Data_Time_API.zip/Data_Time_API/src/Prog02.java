import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

public class Prog02 {

	public static void main(String[] args) {
		LocalDate date = LocalDate.now();
		System.out.println(date.with(TemporalAdjusters.firstDayOfNextMonth()).with(TemporalAdjusters.dayOfWeekInMonth(2,DayOfWeek.SUNDAY )));
	}

}
