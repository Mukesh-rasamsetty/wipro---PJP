import java.time.LocalDate;

public class Prog01 {

	public static void main(String[] args) {
		LocalDate date = LocalDate.now();
		System.out.println(date);
		System.out.println(date.plusDays(10));
	}

}
