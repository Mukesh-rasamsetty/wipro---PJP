import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class Prog03 {

	public static void main(String[] args) {
		LocalDate joining = LocalDate.of(1999, Month.JUNE, 28);

		LocalDate present = LocalDate.now();
		
		Period diff = Period.between(joining, present);
		
		System.out.printf("Difference is %d years, %d months and %d days old",diff.getYears(), diff.getMonths(), diff.getDays());
	}

}
