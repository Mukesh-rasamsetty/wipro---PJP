package com.wipro.automobile.ship;

public class Compartment {
	public int height, width, breadth;

	public Compartment() {
		height = 0;
		width = 0;
		breadth = 0;
	}

	public Compartment(int height, int width, int breadth) {
		this.height = height;
		this.width = width;
		this.breadth = breadth;
	}
}
