package com.automobile;

import com.automobile.twowheeler.Hero;
import com.automobile.twowheeler.Honda;

public class TestClass {

	public static void main(String[] args) {
		System.out.println("****************HERO*****************");
		Hero hero = new Hero("DUET", "1227", "Person1");
		System.out.println(hero.getModelName());
		System.out.println(hero.getOwnerName());
		System.out.println(hero.getRegistrationNumber());
		System.out.println(hero.getSpeed());
		hero.radio();
		System.out.println("****************HONDA*****************");
		Honda honda = new Honda("ACTIVA","1542","Person2");
		System.out.println(honda.getModelName());
		System.out.println(honda.getOwnerName());
		System.out.println(honda.getRegistrationNumber());
		System.out.println(honda.getSpeed());
		honda.cdPlayer();
	}

}
