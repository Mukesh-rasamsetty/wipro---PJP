package com.automobile.twowheeler;

import com.automobile.Vehicle;

public class Honda extends Vehicle{
	private String model, resno, owner;

	public Honda(String m, String r, String o) {
		this.model = m;
		this.owner = o;
		this.resno = r;
	}

	@Override
	public String getModelName() {
		return model;
	}

	@Override
	public String getRegistrationNumber() {
		return resno;
	}

	@Override
	public String getOwnerName() {
		return owner;
	}

	public int getSpeed() {
		return 90;
	}

	public void cdPlayer() {
		System.out.println("CD Player in honda.......!");
	}

}
