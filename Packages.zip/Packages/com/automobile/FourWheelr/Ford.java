package com.automobile.FourWheelr;

import com.automobile.Vehicle;

public class Ford extends Vehicle{
	String model, resno, Owner;

	public Ford(String model, String resno, String Owner) {
		this.Owner = Owner;
		this.resno = resno;
		this.model = model;
	}

	@Override
	public String getModelName() {
		return model;
	}

	@Override
	public String getRegistrationNumber() {
		return resno;
	}

	@Override
	public String getOwnerName() {
		return Owner;
	}

	public int getSpeed() {
		return 220;
	}

	public int tempcontrol() {
		return 2020;
	}
}
