package com.automobile.FourWheelr;

import com.automobile.Vehicle;

public class Logan extends Vehicle {

	String model, resno, Owner;

	public Logan(String model, String resno, String Owner) {
		this.Owner = Owner;
		this.resno = resno;
		this.model = model;
	}

	@Override
	public String getModelName() {
		return model;
	}

	@Override
	public String getRegistrationNumber() {
		return resno;
	}

	@Override
	public String getOwnerName() {
		return Owner;
	}

	public int getSpeed() {
		return 220;
	}

	public int gps() {
		return 2020;
	}

}
