package Test;

public class TestMain {

	public static void main(String[] args) {
		Foundation foundation = new Foundation();
		System.out.println(foundation.var2);
		System.out.println(foundation.var3);
		System.out.println(foundation.var4);
		//System.out.println(foundation.var1); -- Error --
	}

}
