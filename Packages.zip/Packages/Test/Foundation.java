package Test;

public class Foundation {
	private String var1 = "Private";
	public String var4 = "Public";
	protected String var3 = "Protected";
	String var2 = "Default";
}
