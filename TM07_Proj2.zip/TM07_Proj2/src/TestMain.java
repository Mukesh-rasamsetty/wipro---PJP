import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		OperationsOnStringList operationsOnStringList = new OperationsOnStringList();
		abc: while (true) {
			System.out.println("1. Insert \n2. Search \n3. Delete \n4. Display \n5. Exit \nEnter your choice : ");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				System.out.println("Enter the item to be inserted: ");
				operationsOnStringList.insert(sc.next());
				break;

			case 2:
				System.out.println("Enter the item to search : ");
				if (operationsOnStringList.Search(sc.next()))
					System.out.println("Item found in the list.");
				else
					System.out.println("Item not found in the list.");
				break;

			case 3:
				System.out.println("Enter the item to delete : ");
				if (operationsOnStringList.delete(sc.next()))
					System.out.println("Deleted successfully ");
				else
					System.out.println("Item does not exist. ");
				break;

			case 4:
				operationsOnStringList.display();
				break;

			case 5:
				break abc;

			default:
				System.out.println("Enter valid option...!");
				break;
			}
		}
		sc.close();
	}

}
