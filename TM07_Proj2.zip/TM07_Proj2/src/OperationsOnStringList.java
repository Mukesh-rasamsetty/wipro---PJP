import java.util.LinkedList;

public class OperationsOnStringList {
	LinkedList<String> list;
	
	public OperationsOnStringList()	{
		list = new LinkedList<>();
	}
	
	public void insert(String content) {
		list.add(content);
		System.out.println("Inserted Successfully");
	}
	
	public boolean Search(String content) {
		for(String con : list) {
			if(con.equals(content))
				return true;
		}
		return false;
	}
	
	public boolean delete(String content) {
		return list.remove(content);	
	}
	public void display() {
		System.out.println("The Items in the list are : ");
		for(String con : list)
			System.out.println(con);
	}
}
