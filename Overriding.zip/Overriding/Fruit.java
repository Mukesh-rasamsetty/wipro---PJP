
public class Fruit {
	private String name, taste, size;

	public Fruit(String name, String taste, String size) {
		this.name = name;
		this.size = size;
		this.taste = taste;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTaste() {
		return taste;
	}

	public void setTaste(String taste) {
		this.taste = taste;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public void eat() {
		System.out.println(name + " taste is " + taste);
	}
}