
public class Apple extends Fruit {

	public Apple(String size) {
		super("Apple", "Sweet", size);
	}

	@Override
	public void eat() {
		System.out.println("Apple taste is Sweet");
	}
}