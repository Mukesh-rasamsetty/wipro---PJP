
public class Orange extends Fruit {

	public Orange(String size) {
		super("Orange", "Sour", size);
	}

	@Override
	public void eat() {
		System.out.println("Orange taste is sour...!");
	}

}
