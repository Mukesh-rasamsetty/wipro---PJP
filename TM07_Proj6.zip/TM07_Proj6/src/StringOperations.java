import java.util.ArrayList;
import java.util.Scanner;

public class StringOperations {
	public String s1,s2;
	
	public StringOperations(String s1,String s2) {
		this.s1 =s1;
		this.s2 = s2;
	}
	
	public ArrayList<String> Operations1to5()
	{
		ArrayList<String> result = new ArrayList<>();
		StringBuilder str = new StringBuilder();
		for(int i=1; i<s1.length();i= i+2)
		{
			str.append(s2);
			str.append(s1.charAt(i));
		}
		result.add(str.toString());
		int count = s1.split(s2, -1).length - 1;
		if(count >1) {
			result.add(s1.substring(0, s1.lastIndexOf(s2))+ new StringBuilder(s2).reverse());
			result.add(s1.replaceFirst(s2, ""));
		}
		else {
			result.add(s1+s2);
			result.add(s1);
		}
		int len = s2.length();
		if(len % 2 == 0) {
			result.add(s2.substring(0, len/2+1)+s1+s2.substring(len/2+1, len));
		}
		else
			result.add(s2.substring(0, len/2 +2)+s1+s2.substring(len/2+2,len));
		char ch[] = s2.toCharArray();
		for(int i =0 ; i<ch.length;i++)
		{
			s1 = s1.replaceAll(String.valueOf(ch[i]), "*");
		}
		result.add(s1);
		return result;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s1 = sc.next();
		String s2 = sc.next();
		ArrayList<String> str = new StringOperations(s1, s2).Operations1to5();
		System.out.println(str);
		sc.close();
	}
}
