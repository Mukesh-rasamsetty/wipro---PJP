import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyFirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try {
		PrintWriter out = response.getWriter();
		out.println("<HTML>" + "" + "<body bgcolor=YellowGreen>");
		out.println("<table border=1 align=left><tr><th>Cookie Name</th><th>Cookie Value</th></tr>");
			Cookie[] cookies = request.getCookies();
		for(Cookie temp : cookies) {
			out.print("<tr>");
			out.print("<td>"+temp.getName()+"</td>");
			out.print("<td>"+temp.getValue()+"</td>");
			out.print("</tr>");
		}
		out.print("</table></body></html>");
		} catch (Exception e) {
			response.getWriter().print("No Cookies");
		}
	}

	@Override
	public void destroy() {
	}

}
