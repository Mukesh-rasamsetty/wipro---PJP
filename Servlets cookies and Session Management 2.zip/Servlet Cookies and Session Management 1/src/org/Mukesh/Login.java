package org.Mukesh;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter pwriter = response.getWriter();

        String name = request.getParameter("userName");
        String password = request.getParameter("userPassword");
        
        Cookie c1 = new Cookie("userName", name);
        Cookie c2 = new Cookie("password", password);
        
        Cookie[] cook = request.getCookies();
        
        boolean con = true;
        
        for(Cookie temp : cook) {
        	if(temp.getValue().equals(name) || temp.getValue().equals(password))
        	{
        		con = false;
        	}
        }
        if(con)
        {
        	pwriter.print("Welcome, You are visiting for first time");
        	response.addCookie(c1);
        	response.addCookie(c2);
        } else {
        	pwriter.print("Welcome back");
        }
	}
}
