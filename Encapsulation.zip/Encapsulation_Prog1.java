
public class Encapsulation_Prog1 {
	public static void main(String[] args) {
		Book book = new Book("Java", new Author("James", "JamesGossling@gmail.com", 'M'), 999.99, 20);
		System.out.println("...................Book Details...................");
		System.out.println("Name : "+book.getName());
		System.out.println("Price : "+book.getPrice());
		System.out.println("Stock avaliable : "+book.getQtyInStock());
		System.out.println("<--------Author Details ------>\nName : "+book.getAuthor().name+"\nEmail : "+book.getAuthor().email+"\nGender : "+book.getAuthor().gender);
	}
}
