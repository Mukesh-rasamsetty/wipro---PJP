
interface WordCount {
	int count(String str);
}

public class MyClassWithLambda {

	public static void main(String[] args) {
		WordCount wCount = (String str) -> {
				String[] s = str.split(" ");
				return s.length;
			};
		System.out.println(wCount.count("My name is Rasamsetty Mukesh."));
		
	}

}
