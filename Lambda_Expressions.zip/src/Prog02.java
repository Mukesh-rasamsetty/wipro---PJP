import java.util.ArrayList;

public class Prog02 {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>();
		al.add("Apple");
		al.add("Bat");
		al.add("Cat");
		al.add("Dolphin");
		al.add("Elephant");
		al.add("Father");
		al.add("Goose");
		al.add("House");
		al.add("Ice cream");
		al.add("Joker");
		al.add("Kingsman");
		al.forEach(n -> {System.out.println(String.valueOf(new StringBuffer(n).reverse()));});
	}

}
