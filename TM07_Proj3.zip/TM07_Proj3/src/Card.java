
public class Card {
	private char alphabet;
	private int number;
	public Card(char alphabet, int number) {
		this.alphabet = alphabet;
		this.number = number;
	}
	public String get()
	{
		return String.valueOf(alphabet)+" "+String.valueOf(number);
	}
	public char getAlphabet() {
		return alphabet;
	}
	public int getNumber() {
		return number;
	}
}
