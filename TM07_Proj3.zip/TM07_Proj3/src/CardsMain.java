import java.util.Scanner;

public class CardsMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean flag=true;
		int n = 0;
		SetofCards cards = new SetofCards();
		while(flag)
		{
			System.out.println("Enter a card : ");
			char ch= sc.next().charAt(0);
			int  number = sc.nextInt();
			n++;
			flag = cards.insert(new Card(ch, number));
		}
		cards.display(n);
		sc.close();
	}

}
