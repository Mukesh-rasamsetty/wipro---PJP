
public class SetofCards {
	Card[] cards;
	int count;

	public SetofCards() {
		cards = new Card[4];
		count = 0;
	}

	public boolean insert(Card card) {
		boolean flag = true;
		if (count == 0) {
			cards[count] = card;
			count++;
		} else {
			for (int i = 0; i < count; i++) {
				if (cards[i].getAlphabet() == card.getAlphabet()) {
					flag = false;
					break;
				}
			}
			if(flag) {
				cards[count] = card;
				count++;
			}
		}
		if (count < 4)
			return true;
		else
			return false;
	}

	public void display(int n) {
		System.out.println("Four symbols gathered in " + n + " cards.\nCards in Set are : ");
		for (int i = 0; i < cards.length; i++) {
			System.out.println(cards[i].get());
		}
	}
}
