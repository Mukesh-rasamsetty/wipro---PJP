package org.wipro.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.wipro.model.Login;
import org.wipro.model.Registration;
import org.wipro.service.AllServices;

@Controller
public class AllController {

	@Autowired
	AllServices service;

	@RequestMapping("Register")
	public ModelAndView register() {
		return new ModelAndView("register", "registration", new Registration());
	}

	@RequestMapping(method = RequestMethod.POST, value = "CreatePage")
	public ModelAndView createPage(@ModelAttribute("registration") @Valid Registration registration,
			BindingResult result) {
		ModelAndView mv = new ModelAndView("result");
		if (service.add(registration))
			mv.addObject("msg", "Registration Successfull...!");
		else
			mv.addObject("msg", "Registration Failed...!");
		if (result.hasErrors()) {
			System.out.println("has Errors");
			return new ModelAndView("register","registration",registration);
		}
		System.out.println("All good");
		return mv;
	}

	@RequestMapping("Login")
	public ModelAndView login() {
		return new ModelAndView("login", "log", new Login());
	}

	@RequestMapping(value = "LoginPage", method = RequestMethod.POST)
	public ModelAndView loginPage(@ModelAttribute("log") @Validated Login log, BindingResult errors) {
		ModelAndView mv = new ModelAndView("result");
		System.out.println(log);
		mv.addObject("msg", service.logPage(log));
		if (errors.hasErrors())
			return new ModelAndView("login","log", log);
		return mv;

	}
}
