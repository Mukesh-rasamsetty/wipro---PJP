package org.wipro.DAO;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.wipro.model.Login;
import org.wipro.model.Registration;

@Repository
@Transactional
public class LoginDAO {
	
	@Autowired
	SessionFactory factory;
	
	public boolean add(@Valid Registration registration) {
		try {
				Session session = factory.openSession();
				session.beginTransaction();
				session.saveOrUpdate(registration);
				session.getTransaction().commit();
				return true;
		}catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public List<Login> getList() {
		List<Login> list = new ArrayList<Login>();
		Session session = factory.openSession();
		List<Registration> reg = session.createQuery("from registration").getResultList();
		for(Registration temp : reg) {
			list.add(new Login(temp.getUsername(), temp.getPassword()));
		}
		session.close();
		return list;
	}
}
