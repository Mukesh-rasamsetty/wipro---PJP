package org.wipro.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity(name = "registration")
@Table(name = "registration")
public class Registration {
	@Id
	@Column
	@NotEmpty(message = "Enter Username")
	String username;

	@Size(min = 6,max = 6,message = "Password Must be of size of 6")
	@Column
	String password;

	@Column
	@NotEmpty
	@Pattern(regexp = "([A-Z])([0-9]{3})", message="Number Should be one captial letter followed by 3 digits")
	String empNumber;

	@Column
	@Email(message = "Enter Proper Email Address")
	String email;

	public Registration(String username, String password, String empNumber, String email) {
		this.username = username;
		this.password = password;
		this.empNumber = empNumber;
		this.email = email;
	}
	
	public Registration() {
		
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmpNumber() {
		return empNumber;
	}

	public void setEmpNumber(String empNumber) {
		this.empNumber = empNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Registration [username=" + username + ", password=" + password + ", empNumber=" + empNumber + ", email="
				+ email + "]";
	}
	

}
