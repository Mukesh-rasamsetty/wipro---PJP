package org.wipro.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.wipro.DAO.LoginDAO;
import org.wipro.model.Login;
import org.wipro.model.Registration;

@Service
public class AllServices {

	@Autowired
	LoginDAO dao;

	public boolean add(@Valid Registration registration) {
		return dao.add(registration);
	}

	public String logPage(@Valid Login log) {
		List<Login> list = dao.getList();
		for (Login temp : list) {
			if (temp.getUsername().equals(log.getUsername())) {
				if (temp.getPassword().equals(log.getPassword()))
					return "Welcome " + log.getUsername() + " ...!";
				else
					return "The Combination of Username /password is wrong...!";
			}
		}
		return "No such User present with " + log.getUsername() + " ...!";
	}

}
