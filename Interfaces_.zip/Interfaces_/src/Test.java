
public interface Test {
	int myFunction(int a, int b, int c);
}
