
public class Demo {
	public static void main(String[] args) {
		Test t1 = (int a , int b, int c) -> (a+b+c);
		Test t2 = (int a , int b, int c) -> (a*b*c);
		System.out.println(t1.myFunction(10, 20, 30));
		System.out.println(t2.myFunction(10, 20, 30));
	}
}
