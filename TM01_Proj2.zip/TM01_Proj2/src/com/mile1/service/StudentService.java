package com.mile1.service;

import com.mile1.bean.Student;

public class StudentService {
	public int findNumberOfNullMarks(Student[] data) {
		int sum = 0;
		for (int i = 0; i < data.length; i++) {
			try {
				if (data[i].getMarks() != null)
					continue;
			} catch (Exception e) {
				sum++;
			}
		}
		return sum;
	}

	public int findNumberOfNullNames(Student data[]) {
		int sum = 0;
		for (int i = 0; i < data.length; i++) {
			try {
				if (data[i].getName() != null)
					continue;
			} catch (Exception e) {
				sum++;
			}
		}
		return sum;
	}

	public int findNumberOfNullObjects(Student[] data) {
		int sum = 0;
		for (int i = 0; i < data.length; i++) {
			if (data[i] == null)
				sum++;
		}
		return sum;
	}

}
