package com.wipro.sales.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	private static Connection conn = null;
	
	public static Connection getDBConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:Mukesh";
			String username = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found in Connect Method...!");
			
		} catch (SQLException e) {
			System.out.println("SQL Exception in Connect Method...!");
		}
		return conn;
	}
}
