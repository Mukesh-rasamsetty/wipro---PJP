package com.wipro.sales.service;

import java.util.ArrayList;
import java.util.Date;

import com.wipro.sales.bean.Sales;
import com.wipro.sales.bean.SalesReport;
import com.wipro.sales.bean.Stock;
import com.wipro.sales.dao.SalesDao;
import com.wipro.sales.dao.StockDao;

public class Administrator {
	public String insertStock(Stock stockobj) {
		if (stockobj != null) {
			if (stockobj.getProductName().length() > 1) {
				StockDao stock = new StockDao();
				String productID = stock.generatedProductID(stockobj.getProductName());
				stockobj.setProductID(productID);
				stock.insertStock(stockobj);
				return productID;
			}
		}
		return "Data not Valid for insertion";
	}

	public String deleteStock(String ProductID) {
		StockDao stock = new StockDao();
		int i = stock.deleteStock(ProductID);
		if (i == 1)
			return "deleted";
		else
			return "record cannot be deleted";
	}

	public String insertSales(Sales salesobj) {
		if (salesobj != null) {
			SalesDao salesDao = new SalesDao();
			StockDao stockDao = new StockDao();
			Stock sales = stockDao.getStock(salesobj.getProductID());
			if (sales != null) {
				if (salesobj.getQuantitySold() < sales.getQuantityOnHand()) {
					if (salesobj.getSalesDate().after(new Date()))
						return "Invalid Date";
					String salesID = salesDao.generateSalesID(salesobj.getSalesDate());
					salesobj.setSalesID(salesID);
					if (salesDao.insertSales(salesobj) == 0) {
						if (stockDao.updateStock(salesobj.getProductID(), sales.getQuantityOnHand()) == 1)
							return "Sales Completed";
						else
							return "Error";
					}
					return "Sales Completed";
				}
				return "Not enough stock on hand for sales";
			}
			return "Unknown Product for sales";
		}
		return "�Object not valid for insertion";
	}

	public ArrayList<SalesReport> getSalesReport() {
		return new SalesDao().getSalesReport();
	}
}
