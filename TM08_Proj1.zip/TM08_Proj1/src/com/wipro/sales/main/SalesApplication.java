package com.wipro.sales.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import com.wipro.sales.bean.Sales;
import com.wipro.sales.bean.SalesReport;
import com.wipro.sales.bean.Stock;
import com.wipro.sales.service.Administrator;

public class SalesApplication {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Administrator administrator = new Administrator();
		try {
			abc: while(true) {
				System.out.print("\t1. Insert Stock \n\t2. Delete Stock \n\t3. Insert Sales \n\t4. View Sales Report \nEnter your Choice: ");
				int n = sc.nextInt();
				sc.nextLine();
				switch (n) {
				case 1:
					Stock stock = new Stock();
					System.out.print("Enter Product name : ");
					stock.setProductName(sc.nextLine());
					System.out.print("Enter Quantity on Hand : ");
					stock.setQuantityOnHand(sc.nextInt());
					System.out.print("Enter Price per unit level : ");
					stock.setProductUnitPrice(sc.nextInt());
					System.out.print("Enter reorder Level : ");
					stock.setReorderLevel(sc.nextInt());
					System.out.println(administrator.insertStock(stock));
					break;
					
				case 2:
					System.out.print("Enter Product ID to remove : ");
					System.out.println(administrator.deleteStock(sc.next()));
					break;
	
				case 3:
					Sales sales = new Sales();
					System.out.print("Enter date (dd-mm-yyyy): ");
					String sDate = sc.nextLine();  
				    Date date = new SimpleDateFormat("dd-mm-yyyy").parse(sDate); 
					sales.setSalesDate(date);
					System.out.print("Enter product id: ");
					sales.setProductID(sc.nextLine());
					System.out.print("Enter quantity sold: ");
					sales.setQuantitySold(sc.nextInt());
					sc.nextLine();
					System.out.print("Enter sales price per unit: ");
					sales.setSalesPricePerUnit(sc.nextDouble());
					System.out.println(administrator.insertSales(sales));
					break;
					
				case 4:
					ArrayList<SalesReport> salesReports = administrator.getSalesReport();
					System.out.println("|---------------------------------------------------------------------------------------------------------------------------------|");
					System.out.printf("| %10s | %10s | %10s | %10s | %10s | %10s | %10s | %10s |","SALES_ID","SALES_DATE","PRODUCT_ID","PRODUCT_NAME","QUANTITY_SOLD","PRODUCT_UNIT_PRICE","SALES_PRICE_PER_UNIT","PROFIT_AMOUNT");
					System.out.println();
					System.out.println("|---------------------------------------------------------------------------------------------------------------------------------|");
					for(SalesReport sales1 : salesReports) {
						System.out.printf("| %10s | %10s | %10s | %10s | %13d | %18f | %20f | %13f |",sales1.getSalesID(),sales1.getSalesDate(),sales1.getProductID(),sales1.getProductName(),sales1.getQuantitySold(),sales1.getProductUnitPrice(),sales1.getSalesPricePerUnit(),sales1.getProfitAmount());
						System.out.println();
					}
					System.out.println("|---------------------------------------------------------------------------------------------------------------------------------|");
					break;
				default:
					break abc;
				}
			}
		} catch(NullPointerException | ParseException e)
		{
			System.out.println("SOMETHING WENT WRONG IN MAIN METHOD...!");
		}
		sc.close();
	}

}
