import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Employee {
	public Employee() {
		File file = new File("E:/WIPRO/TM06_Proj1/src/Employee Details.txt");
		file.delete();
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void add(Scanner sc) {
		System.out.print("Enter Employee ID: ");
		int id = sc.nextInt();
		System.out.print("Enter Employee Name: ");
		String name = sc.next();
		System.out.print("Enter Employee Age: ");
		int age = sc.nextInt();
		System.out.print("Enter Employee Salary: ");
		double salary = sc.nextDouble();
		try {
			FileWriter out = new FileWriter("E:/WIPRO/TM06_Proj1/src/Employee Details.txt",true); 
			String str = id+" "+name+" "+age+" "+salary+"\n";
			out.write(str);
			out.close();
		} catch (FileNotFoundException  e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void list() {
		try {
			FileInputStream fileInputStream = new FileInputStream("E:/WIPRO/TM06_Proj1/src/Employee Details.txt");
			int c;
			while((c = fileInputStream.read()) != -1)
			{
				System.out.print((char)c);
			}
			fileInputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
