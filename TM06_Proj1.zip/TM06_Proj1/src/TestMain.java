import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Employee emp = new Employee();
		abc: while(true) {
			System.out.println(" Main Menu\n 1. Add an Employee\n 2. Display All\n 3. Exit ");
			int n = sc.nextInt();
			switch(n) {
			case 1:
				emp.add(sc);
				break;
			case 2:
				emp.list();
				break;
			case 3:
				break abc;
			default :
				System.out.println("Enter Valid option..!");
			}
		}
		sc.close();
	}

}
