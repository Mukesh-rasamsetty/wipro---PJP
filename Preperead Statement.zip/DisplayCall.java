import java.util.Scanner;

public class DisplayCall {

	public static void main(String[] args) {
		System.out.println("Welcome to ABC INTERNATIONAL SCHOOL");
		System.out.println("Enter ROLL NUMBER to display particluar list( otherwise press -1 ): ");
		Scanner sc = new Scanner(System.in);
		String roll = String.valueOf(sc.nextInt());  
		DAOClass daoClass = new DAOClass();
		daoClass.connect();
		if(roll.equals("-1"))
		{
			daoClass.display();
		}
		else
		{
			if (daoClass.display(Integer.parseInt(args[1])))
				System.out.println("----------------------------------------------");
			else
				System.out.println("Record not FOund!/nSOMETHING WENT WRONG");
		}
		daoClass.disconnect();
		sc.close();
	}

}
