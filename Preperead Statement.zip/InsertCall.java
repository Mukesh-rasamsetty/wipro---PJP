import java.util.Scanner;

public class InsertCall {

	public static void main(String[] args) {
		System.out.println("Welcome to ABC INTERNATIONAL SCHOOL");
		System.out.println("Enter ROLL NUMBER : ");
		Scanner sc = new Scanner(System.in);
		String roll = String.valueOf(sc.nextInt()); 
		System.out.println("Enter name : ");
		String name = sc.next();
		System.out.println("Enter Standard : ");
		String stand = sc.next();
		System.out.println("Enter daate of birth in format(YYYY-MM-DD) : ");
		String dob = sc.next();
		System.out.println("Enter fee : ");
		String fee = String.valueOf(sc.nextInt()); 
		DAOClass daoClass = new DAOClass();
		daoClass.connect();
		if (daoClass.insert(roll,name,stand,dob,fee))
			System.out.println("Inserted Successfully...!");
		else
			System.out.println("Insertion Failed...!");
		daoClass.disconnect();
		sc.close();
	}

}
