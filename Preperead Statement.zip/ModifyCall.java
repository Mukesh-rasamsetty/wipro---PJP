import java.util.Scanner;

public class ModifyCall {

	public static void main(String[] args) {
		System.out.println("Welcome to ABC INTERNATIONAL SCHOOL");
		System.out.println("Enter ROLL NUMBER to Modify : ");
		Scanner sc = new Scanner(System.in);
		String roll = String.valueOf(sc.nextInt()); 
		System.out.println("Enter fee : ");
		String fee = String.valueOf(sc.nextInt()); 
		DAOClass daoClass = new DAOClass();
		daoClass.connect();
		if (daoClass.modify(roll,fee))
			System.out.println("Modified Successfully...!");
		else
			System.out.println("Not Found!\nSOMETHING WENT WRONG........!");
		daoClass.disconnect();
		sc.close();
	}

}
