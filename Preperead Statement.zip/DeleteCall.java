import java.util.Scanner;

public class DeleteCall {

	public static void main(String[] args) {
		System.out.println("Welcome to ABC INTERNATIONAL SCHOOL");
		System.out.println("Enter ROLL NUMBER to delete : ");
		Scanner sc = new Scanner(System.in);
		String roll = String.valueOf(sc.nextInt()); 
		DAOClass daoClass = new DAOClass();
		daoClass.connect();
		if (daoClass.Delete(Integer.parseInt(roll)))
			System.out.println("Deletion Successfull...!");
		else
			System.out.println("Record Not Found...!");
		daoClass.disconnect();
		sc.close();
	}

}
