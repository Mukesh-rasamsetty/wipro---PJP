import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DAOClass {

	private Connection conn;

	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:Mukesh";
			String username = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, username, password);
			if (conn != null)
				System.out.println("Connection established...!");
			else
				System.out.println("Something went Wrong in Connecting...!");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found in Connect Method...!");
			
		} catch (SQLException e) {
			System.out.println("SQL Exception in Connect Method...!");
		}
	}

	public boolean Delete(int roll) {
		String sql = "DELETE FROM STUDENT WHERE ROLLNO = " + roll;
		Statement stmt;
		try {
			stmt = conn.createStatement();
			if (stmt.executeUpdate(sql) == 1)
				return true;
		} catch (SQLException e) {
			System.out.println("SQL Exception in Delete Method...!");
		}
		return false;

	}

	public boolean insert(String roll, String name, String standard, String dob, String fees) {
		String sql = "INSERT INTO STUDENT VALUES(" + roll + ",'" + name + "','" + standard + "','" + dob + "'," + fees
				+ ")";
		Statement stmt;
		try {
			stmt = conn.createStatement();
			if (stmt.executeUpdate(sql) == 1)
				return true;
		} catch (SQLException e) {
			System.out.println("SQL Exception in Insert Method...!");
		}
		return false;
	}

	public boolean modify(String roll, String fees) {
		String sql = "UPDATE STUDENT SET FEES = " + fees + " WHERE ROLLNO = " + roll;
		try {
			Statement stmt = conn.createStatement();
			if (stmt.executeUpdate(sql) == 1)
				return true;
		} catch (SQLException e) {
			System.out.println("SQL Exception in Modify Method...!");
		}

		return false;
	}

	public boolean display(int roll) {
		String sql = "SELECT * FROM STUDENT WHERE ROLLNO = " + roll;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				System.out.println(roll + " Details\n=======================");
				System.out.println("ROLL NUMBER   : " + rs.getInt("ROLLNO"));
				System.out.println("NAME 		  : " + rs.getString("NAME"));
				System.out.println("STANDARD      : " + rs.getString("STANDARD"));
				System.out.println("DATE OF BIRTH : " + rs.getString("DOB"));
				System.out.println("FEES          : " + rs.getInt("FEES"));
			}
			return true;
		} catch (SQLException e) {
			System.out.println("SQL Exception in Display Method...!");
		}

		return false;
	}

	public void display() {
		String sql = "SELECT * FROM STUDENT";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println("-----------------------------------------------------------------------------");
		    System.out.printf("%10s %20s %10s %15s %10s", "ROLL NUMBER", "NAME", "STANDARD", "DATE OF BIRTH", "FEES");
		    System.out.println();
		    System.out.println("-----------------------------------------------------------------------------");
		    while(rs.next()) {
		        System.out.format("%10d %20s %10s %15s %10d",rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
		        System.out.println();
		    }
		    System.out.println("-----------------------------------------------------------------------------");
		} catch (SQLException e) {
			System.out.println("SQL Exception in Display Method...!");
		}

	}

	public void disconnect() {
		try {
			conn.close();
			System.out.println("Disconnected Successfully....!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
