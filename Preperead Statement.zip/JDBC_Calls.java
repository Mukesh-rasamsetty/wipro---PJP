
public class JDBC_Calls {

	public static void main(String[] args) {
		DAOClass daoClass = new DAOClass();
		daoClass.connect();
		switch (Integer.parseInt(args[0])) {
		case 1:
			if (daoClass.insert(args[1], args[2], args[3], args[4], args[5]))
				System.out.println("Inserted Successfully...!");
			else
				System.out.println("Insertion Failed...!");
			break;
		case 2:
			if (daoClass.Delete(Integer.parseInt(args[1])))
				System.out.println("Deletion Successfull...!");
			else
				System.out.println("Record Not Found...!");
			break;
		case 3:
			if (daoClass.modify(args[1], args[2]))
				System.out.println("Modified Successfully...!");
			else
				System.out.println("Not Found!\nSOMETHING WENT WRONG........!");
			break;
		case 4:
			if (args.length == 2) {
				if (daoClass.display(Integer.parseInt(args[1])))
					System.out.println("----------------------------------------------");
				else
					System.out.println("Record not FOund!/nSOMETHING WENT WRONG");
			} else {
				daoClass.display();
			}
			break;
		default:
			System.out.println("Enter valid Data...!");
		}
		daoClass.disconnect();
	}

}
